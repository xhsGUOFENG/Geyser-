package org.cloudburstmc.protocol.bedrock.codec.v898_netease;

import io.netty.buffer.ByteBuf;
import nc.geyserext.netease.config.CompatSettings;
import org.cloudburstmc.protocol.bedrock.codec.EntityDataTypeMap;
import org.cloudburstmc.protocol.bedrock.codec.v898.BedrockCodecHelper_v898;
import org.cloudburstmc.protocol.bedrock.data.Ability;
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData;
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerSlotType;
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.TextProcessingEventOrigin;
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.action.ItemStackRequestActionType;
import org.cloudburstmc.protocol.common.util.TypeMap;
import org.cloudburstmc.protocol.common.util.VarInts;

import java.math.BigInteger;
import java.util.Set;

/**
 * 网易 898（Minecraft 1.21.130）协议 helper。
 *
 * <p>网易客户端在 {@link PlayerAuthInputData} 位图的 STOP_FLYING 之后插入了两个私有位，
 * 其后的所有标准标志都要整体后移两位。布吉岛 netease/1.21.130 的
 * NeteasePlayerAuthInputSerializer 使用同一布局。</p>
 *
 * <p>位图模式由 {@code auth-input-bitmap} 配置决定：</p>
 * <ul>
 *   <li><b>netease</b>（默认）：按网易两位偏移读写；</li>
 *   <li><b>standard</b>：完全使用原版 898 位图；</li>
 *   <li><b>legacy</b>：保留旧版一位偏移实现，仅用于复现历史行为与排障。</li>
 * </ul>
 */
public class BedrockCodecHelper_v898_NetEase extends BedrockCodecHelper_v898 {
    /** 网易私有位从 STOP_FLYING 之后开始插入。 */
    private static final int NETEASE_SHIFT_AFTER = PlayerAuthInputData.STOP_FLYING.ordinal();
    /** 旧实现中跳过的一位私有位。 */
    private static final int LEGACY_PRIVATE_BIT = PlayerAuthInputData.RECEIVED_SERVER_DATA.ordinal() + 1;
    private static final int NETEASE_INPUT_BITS = PlayerAuthInputData.values().length + 2;
    private static final PlayerAuthInputData[] NETEASE_WIRE_TO_INPUT = createMapping();

    private final String bitmapMode;

    public BedrockCodecHelper_v898_NetEase(EntityDataTypeMap entityData, TypeMap<Class<?>> gameRulesTypes,
                                           TypeMap<ItemStackRequestActionType> stackRequestActionTypes,
                                           TypeMap<ContainerSlotType> containerSlotTypes, TypeMap<Ability> abilities,
                                           TypeMap<TextProcessingEventOrigin> textProcessingEventOrigins) {
        this(entityData, gameRulesTypes, stackRequestActionTypes, containerSlotTypes, abilities,
                textProcessingEventOrigins, CompatSettings.BITMAP_NETEASE);
    }

    public BedrockCodecHelper_v898_NetEase(EntityDataTypeMap entityData, TypeMap<Class<?>> gameRulesTypes,
                                           TypeMap<ItemStackRequestActionType> stackRequestActionTypes,
                                           TypeMap<ContainerSlotType> containerSlotTypes, TypeMap<Ability> abilities,
                                           TypeMap<TextProcessingEventOrigin> textProcessingEventOrigins,
                                           String bitmapMode) {
        super(entityData, gameRulesTypes, stackRequestActionTypes, containerSlotTypes, abilities, textProcessingEventOrigins);
        this.bitmapMode = bitmapMode == null ? CompatSettings.BITMAP_NETEASE : bitmapMode;
    }

    private static PlayerAuthInputData[] createMapping() {
        PlayerAuthInputData[] mapping = new PlayerAuthInputData[NETEASE_INPUT_BITS];
        for (PlayerAuthInputData input : PlayerAuthInputData.values()) {
            int ordinal = input.ordinal();
            int wireBit = ordinal <= NETEASE_SHIFT_AFTER ? ordinal : ordinal + 2;
            mapping[wireBit] = input;
        }
        return mapping;
    }

    @Override
    public <T extends Enum<?>> void readLargeVarIntFlags(ByteBuf buffer, Set<T> flags, Class<T> clazz) {
        if (clazz != PlayerAuthInputData.class || CompatSettings.BITMAP_STANDARD.equals(bitmapMode)) {
            super.readLargeVarIntFlags(buffer, flags, clazz);
            return;
        }
        if (CompatSettings.BITMAP_LEGACY.equals(bitmapMode)) {
            BigInteger bits = VarInts.readUnsignedBigVarInt(buffer, clazz.getEnumConstants().length);
            for (T flag : clazz.getEnumConstants()) {
                int ordinal = flag.ordinal();
                if (ordinal == LEGACY_PRIVATE_BIT) continue;
                int bit = ordinal > LEGACY_PRIVATE_BIT ? ordinal - 1 : ordinal;
                if (bits.testBit(bit)) flags.add(flag);
            }
            return;
        }
        BigInteger bits = VarInts.readUnsignedBigVarInt(buffer, NETEASE_INPUT_BITS);
        flags.clear();
        int wireBits = Math.min(bits.bitLength(), NETEASE_WIRE_TO_INPUT.length);
        for (int wireBit = 0; wireBit < wireBits; wireBit++) {
            PlayerAuthInputData input = NETEASE_WIRE_TO_INPUT[wireBit];
            if (input != null && bits.testBit(wireBit)) {
                flags.add(clazz.cast(input));
            }
        }
    }

    @Override
    public <T extends Enum<?>> void writeLargeVarIntFlags(ByteBuf buffer, Set<T> flags, Class<T> clazz) {
        if (clazz != PlayerAuthInputData.class || CompatSettings.BITMAP_STANDARD.equals(bitmapMode)) {
            super.writeLargeVarIntFlags(buffer, flags, clazz);
            return;
        }
        BigInteger bits = BigInteger.ZERO;
        if (CompatSettings.BITMAP_LEGACY.equals(bitmapMode)) {
            for (T flag : flags) {
                int ordinal = flag.ordinal();
                if (ordinal == LEGACY_PRIVATE_BIT) continue;
                int bit = ordinal > LEGACY_PRIVATE_BIT ? ordinal + 1 : ordinal;
                bits = bits.setBit(bit);
            }
        } else {
            for (T flag : flags) {
                int ordinal = flag.ordinal();
                int wireBit = ordinal <= NETEASE_SHIFT_AFTER ? ordinal : ordinal + 2;
                bits = bits.setBit(wireBit);
            }
        }
        VarInts.writeUnsignedBigVarInt(buffer, bits);
    }
}
