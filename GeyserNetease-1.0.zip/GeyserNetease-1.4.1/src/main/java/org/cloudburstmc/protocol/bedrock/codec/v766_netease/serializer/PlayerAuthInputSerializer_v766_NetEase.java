package org.cloudburstmc.protocol.bedrock.codec.v766_netease.serializer;

import io.netty.buffer.ByteBuf;
import org.cloudburstmc.math.vector.Vector2f;
import org.cloudburstmc.math.vector.Vector3f;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.v766.serializer.PlayerAuthInputSerializer_v766;
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData;
import org.cloudburstmc.protocol.bedrock.data.PlayerBlockActionData;
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket;
import org.cloudburstmc.protocol.common.util.Preconditions;
import org.cloudburstmc.protocol.common.util.VarInts;

public class PlayerAuthInputSerializer_v766_NetEase extends PlayerAuthInputSerializer_v766 {
    public static final PlayerAuthInputSerializer_v766_NetEase INSTANCE = new PlayerAuthInputSerializer_v766_NetEase();

    /**
     * 网易在 PlayerAuthInput 末尾单独发送 onGround；当前协议库的
     * PlayerAuthInputPacket 还没有这个字段，所以先用线程本地标记传给
     * NetEaseUpstreamHandler，在移动翻译前修正旧 Geyser 的着地判定。
     * 解码和 handle 都发生在同一事件循环线程上，取完即清。
     */
    private static final ThreadLocal<Boolean> NET_EASE_ON_GROUND = new ThreadLocal<>();

    public static Boolean consumeOnGround() {
        Boolean value = NET_EASE_ON_GROUND.get();
        NET_EASE_ON_GROUND.remove();
        return value;
    }

    /** 越界索引会抛 IllegalArgumentException（畸形包直接断开），而不是 ArrayIndexOutOfBoundsException。 */
    private static <T> T readEnumSafe(T[] values, int index, String what) {
        Preconditions.checkArgument(index >= 0 && index < values.length, "Invalid " + what + " index: " + index);
        return values[index];
    }

    @Override
    public void serialize(ByteBuf buffer, BedrockCodecHelper helper, PlayerAuthInputPacket packet) {
        Vector3f rotation = packet.getRotation();
        buffer.writeFloatLE(rotation.getX());
        buffer.writeFloatLE(rotation.getY());
        helper.writeVector3f(buffer, packet.getPosition());
        buffer.writeFloatLE(packet.getMotion().getX());
        buffer.writeFloatLE(packet.getMotion().getY());
        buffer.writeFloatLE(rotation.getZ());
        helper.writeLargeVarIntFlags(buffer, packet.getInputData(), PlayerAuthInputData.class);
        VarInts.writeUnsignedInt(buffer, packet.getInputMode().ordinal());
        VarInts.writeUnsignedInt(buffer, packet.getPlayMode().ordinal());
        writeInteractionModel(buffer, helper, packet);
        helper.writeVector2f(buffer, packet.getInteractRotation());
        VarInts.writeUnsignedLong(buffer, packet.getTick());
        helper.writeVector3f(buffer, packet.getDelta());
        buffer.writeBoolean(false);

        if (packet.getInputData().contains(PlayerAuthInputData.PERFORM_ITEM_INTERACTION)) {
            writeItemUseTransaction(buffer, helper, packet.getItemUseTransaction());
        }
        if (packet.getInputData().contains(PlayerAuthInputData.PERFORM_ITEM_STACK_REQUEST)) {
            helper.writeItemStackRequest(buffer, packet.getItemStackRequest());
        }
        if (packet.getInputData().contains(PlayerAuthInputData.PERFORM_BLOCK_ACTIONS)) {
            VarInts.writeInt(buffer, packet.getPlayerActions().size());
            for (PlayerBlockActionData actionData : packet.getPlayerActions()) {
                writePlayerBlockActionData(buffer, helper, actionData);
            }
        }
        if (packet.getInputData().contains(PlayerAuthInputData.IN_CLIENT_PREDICTED_IN_VEHICLE)) {
            helper.writeVector2f(buffer, packet.getVehicleRotation());
            VarInts.writeLong(buffer, packet.getPredictedVehicle());
        }
        helper.writeVector2f(buffer, packet.getAnalogMoveVector());
        helper.writeVector3f(buffer, packet.getCameraOrientation());
        helper.writeVector2f(buffer, packet.getRawMoveVector());
        buffer.writeBoolean(false);
        Vector2f playerRotationToCamera = Vector2f.ZERO;
        buffer.writeFloatLE(playerRotationToCamera.getX());
        buffer.writeFloatLE(playerRotationToCamera.getY());
        buffer.writeBoolean(false);
        buffer.writeBoolean(packet.getInputData().contains(PlayerAuthInputData.VERTICAL_COLLISION));
        buffer.writeByte(0);
    }

    @Override
    public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, PlayerAuthInputPacket packet) {
        float x = buffer.readFloatLE();
        float y = buffer.readFloatLE();
        packet.setPosition(helper.readVector3f(buffer));
        packet.setMotion(Vector2f.from(buffer.readFloatLE(), buffer.readFloatLE()));
        float z = buffer.readFloatLE();
        packet.setRotation(Vector3f.from(x, y, z));
        helper.readLargeVarIntFlags(buffer, packet.getInputData(), PlayerAuthInputData.class);
        packet.setInputMode(readEnumSafe(INPUT_MODES, VarInts.readUnsignedInt(buffer), "input mode"));
        packet.setPlayMode(readEnumSafe(CLIENT_PLAY_MODES, VarInts.readUnsignedInt(buffer), "play mode"));
        readInteractionModel(buffer, helper, packet);
        packet.setInteractRotation(helper.readVector2f(buffer));
        packet.setTick(VarInts.readUnsignedLong(buffer));
        packet.setDelta(helper.readVector3f(buffer));
        buffer.readBoolean();

        if (packet.getInputData().contains(PlayerAuthInputData.PERFORM_ITEM_INTERACTION)) {
            packet.setItemUseTransaction(readItemUseTransaction(buffer, helper));
        }
        if (packet.getInputData().contains(PlayerAuthInputData.PERFORM_ITEM_STACK_REQUEST)) {
            packet.setItemStackRequest(helper.readItemStackRequest(buffer));
        }
        if (packet.getInputData().contains(PlayerAuthInputData.PERFORM_BLOCK_ACTIONS)) {
            helper.readArray(buffer, packet.getPlayerActions(), VarInts::readInt, this::readPlayerBlockActionData, 32);
        }
        if (packet.getInputData().contains(PlayerAuthInputData.IN_CLIENT_PREDICTED_IN_VEHICLE)) {
            packet.setVehicleRotation(helper.readVector2f(buffer));
            packet.setPredictedVehicle(VarInts.readLong(buffer));
        }
        packet.setAnalogMoveVector(helper.readVector2f(buffer));
        packet.setCameraOrientation(helper.readVector3f(buffer));
        packet.setRawMoveVector(helper.readVector2f(buffer));
        buffer.readBoolean();
        buffer.readFloatLE(); buffer.readFloatLE();
        buffer.readBoolean();
        boolean onGround = buffer.readBoolean();
        NET_EASE_ON_GROUND.set(onGround);
        buffer.readByte();
    }
}
