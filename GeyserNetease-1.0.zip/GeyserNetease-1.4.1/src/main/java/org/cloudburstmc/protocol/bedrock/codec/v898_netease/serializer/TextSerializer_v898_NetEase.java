package org.cloudburstmc.protocol.bedrock.codec.v898_netease.serializer;

import io.netty.buffer.ByteBuf;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.v898.serializer.TextSerializer_v898;
import org.cloudburstmc.protocol.bedrock.packet.TextPacket;

/**
 * 网易 898 文本包序列化器。
 *
 * <p>网易客户端在标准 1.21.130 文本包负载之后，对 CHAT/POPUP 还追加一个额外字符串字段
 * （与 686/860 网易版一致的行为）。这里沿用旧版处理：写出空串，读取时按同一结构跳过。</p>
 */
public class TextSerializer_v898_NetEase extends TextSerializer_v898 {
    public static final TextSerializer_v898_NetEase INSTANCE = new TextSerializer_v898_NetEase();

    @Override
    public void serialize(ByteBuf buffer, BedrockCodecHelper helper, TextPacket packet) {
        super.serialize(buffer, helper, packet);

        TextPacket.Type type = packet.getType();
        if (type == TextPacket.Type.CHAT || type == TextPacket.Type.POPUP) {
            helper.writeString(buffer, textExtra(packet));
        }
    }

    /**
     * 该额外字符串的确切语义尚未确认，默认写空串（与历史行为一致）。
     * 可用 {@code -DGeyserNetease.TextExtraField=message} 改为写消息原文以便实测验证。
     */
    private static String textExtra(TextPacket packet) {
        if ("message".equals(System.getProperty("GeyserNetease.TextExtraField"))
                && packet.getMessage() != null) {
            return packet.getMessage();
        }
        return "";
    }

    @Override
    public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, TextPacket packet) {
        super.deserialize(buffer, helper, packet);

        TextPacket.Type type = packet.getType();
        if (type == TextPacket.Type.CHAT || type == TextPacket.Type.POPUP) {
            helper.readString(buffer);
        }
    }
}