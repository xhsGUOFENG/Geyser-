package org.cloudburstmc.protocol.bedrock.codec.v860_netease;

import io.netty.buffer.ByteBuf;
import org.cloudburstmc.protocol.bedrock.codec.EntityDataTypeMap;
import org.cloudburstmc.protocol.bedrock.codec.v844.BedrockCodecHelper_v844;
import org.cloudburstmc.protocol.bedrock.data.Ability;
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData;
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerSlotType;
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.TextProcessingEventOrigin;
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.action.ItemStackRequestActionType;
import org.cloudburstmc.protocol.common.util.TypeMap;
import org.cloudburstmc.protocol.common.util.VarInts;

import java.math.BigInteger;
import java.util.Set;

/**
 * 网易 860 helper：STOP_FLYING 之后插入两个私有位，
 * 后续标准标志整体后移两位（与 898 相同）。
 */
public class BedrockCodecHelper_v860_NetEase extends BedrockCodecHelper_v844 {
    private static final int NETEASE_SHIFT_AFTER = PlayerAuthInputData.STOP_FLYING.ordinal();
    private static final int NETEASE_INPUT_BITS = PlayerAuthInputData.values().length + 2;
    private static final PlayerAuthInputData[] NETEASE_WIRE_TO_INPUT = createMapping();

    public BedrockCodecHelper_v860_NetEase(EntityDataTypeMap entityData, TypeMap<Class<?>> gameRulesTypes,
                                           TypeMap<ItemStackRequestActionType> stackRequestActionTypes,
                                           TypeMap<ContainerSlotType> containerSlotTypes, TypeMap<Ability> abilities,
                                           TypeMap<TextProcessingEventOrigin> textProcessingEventOrigins) {
        super(entityData, gameRulesTypes, stackRequestActionTypes, containerSlotTypes, abilities, textProcessingEventOrigins);
    }

    private static PlayerAuthInputData[] createMapping() {
        PlayerAuthInputData[] mapping = new PlayerAuthInputData[NETEASE_INPUT_BITS];
        for (PlayerAuthInputData input : PlayerAuthInputData.values()) {
            int ordinal = input.ordinal();
            int wireBit = ordinal <= NETEASE_SHIFT_AFTER ? ordinal : ordinal + 2;
            mapping[wireBit] = input;
        }
        return mapping;
    }

    @Override
    public <T extends Enum<?>> void readLargeVarIntFlags(ByteBuf buffer, Set<T> flags, Class<T> clazz) {
        if (clazz != PlayerAuthInputData.class) {
            super.readLargeVarIntFlags(buffer, flags, clazz);
            return;
        }
        BigInteger bits = VarInts.readUnsignedBigVarInt(buffer, NETEASE_INPUT_BITS);
        flags.clear();
        int wireBits = Math.min(bits.bitLength(), NETEASE_WIRE_TO_INPUT.length);
        for (int wireBit = 0; wireBit < wireBits; wireBit++) {
            PlayerAuthInputData input = NETEASE_WIRE_TO_INPUT[wireBit];
            if (input != null && bits.testBit(wireBit)) {
                flags.add(clazz.cast(input));
            }
        }
    }

    @Override
    public <T extends Enum<?>> void writeLargeVarIntFlags(ByteBuf buffer, Set<T> flags, Class<T> clazz) {
        if (clazz != PlayerAuthInputData.class) {
            super.writeLargeVarIntFlags(buffer, flags, clazz);
            return;
        }
        BigInteger bits = BigInteger.ZERO;
        for (T flag : flags) {
            int ordinal = flag.ordinal();
            int wireBit = ordinal <= NETEASE_SHIFT_AFTER ? ordinal : ordinal + 2;
            bits = bits.setBit(wireBit);
        }
        VarInts.writeUnsignedBigVarInt(buffer, bits);
    }
}
