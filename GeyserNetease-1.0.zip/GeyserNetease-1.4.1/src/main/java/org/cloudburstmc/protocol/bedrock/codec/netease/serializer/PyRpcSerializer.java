package org.cloudburstmc.protocol.bedrock.codec.netease.serializer;

import io.netty.buffer.ByteBuf;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.BedrockPacketSerializer;
import org.cloudburstmc.protocol.bedrock.packet.PyRpcPacket;

public class PyRpcSerializer implements BedrockPacketSerializer<PyRpcPacket> {
    public static final PyRpcSerializer INSTANCE = new PyRpcSerializer();

    /**
     * 网易 Python RPC 包尾的固定 4 字节（08 D4 94 00），不是普通的 msgId。
     * 客户端会校验该值；写成 00 00 00 00 时包会被丢弃。
     */
    public static final long TRAILER = 0x08D49400L;

    @Override
    public void serialize(ByteBuf buffer, BedrockCodecHelper helper, PyRpcPacket packet) {
        helper.writeByteArray(buffer, packet.getData());
        long trailer = packet.getMsgId() == 0L ? TRAILER : packet.getMsgId();
        buffer.writeInt((int) trailer);
    }

    @Override
    public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, PyRpcPacket packet) {
        packet.setData(helper.readByteArray(buffer));
        packet.setMsgId(buffer.readUnsignedInt());
    }
}
