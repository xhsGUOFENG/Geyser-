package org.cloudburstmc.protocol.bedrock.codec.v898_netease;

import nc.geyserext.netease.NeteaseExtension;
import nc.geyserext.netease.config.CompatSettings;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.codec.netease.serializer.ConfirmSkinSerializer;
import org.cloudburstmc.protocol.bedrock.codec.netease.serializer.NetEaseJsonSerializer;
import org.cloudburstmc.protocol.bedrock.codec.netease.serializer.PlayerEnchantOptionsSerializer_v407_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.netease.serializer.PyRpcSerializer;
import org.cloudburstmc.protocol.bedrock.codec.netease.serializer.StoreBuySuccessSerializer;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.CommandOutputSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v388.serializer.InteractSerializer_v388;
import org.cloudburstmc.protocol.bedrock.codec.v567.serializer.CommandRequestSerializer_v567;
import org.cloudburstmc.protocol.bedrock.codec.v594.serializer.AvailableCommandsSerializer_v594;
import org.cloudburstmc.protocol.bedrock.codec.v671.serializer.ResourcePackStackSerializer_v671;
import org.cloudburstmc.protocol.bedrock.codec.v685.serializer.EventSerializer_v685;
import org.cloudburstmc.protocol.bedrock.codec.v686_netease.serializer.TextSerializer_v686_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v712.Bedrock_v712;
import org.cloudburstmc.protocol.bedrock.codec.v748.serializer.MobEffectSerializer_v748;
import org.cloudburstmc.protocol.bedrock.codec.v766_netease.serializer.PlayerAuthInputSerializer_v766_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v827.serializer.StartGameSerializer_v827;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.AnimateSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v859.serializer.AnimateSerializer_v859;
import org.cloudburstmc.protocol.bedrock.codec.v860_netease.serializer.BiomeDefinitionListSerializer_v860_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v860_netease.serializer.ContainerOpenSerializer_v860_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v898.Bedrock_v898;
import org.cloudburstmc.protocol.bedrock.codec.v898_netease.serializer.TextSerializer_v898_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v898_netease.serializer.NeteaseAnimateSerializer;
import org.cloudburstmc.protocol.bedrock.data.PacketRecipient;
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerSlotType;
import org.cloudburstmc.protocol.bedrock.packet.AnimatePacket;
import org.cloudburstmc.protocol.bedrock.packet.AvailableCommandsPacket;
import org.cloudburstmc.protocol.bedrock.packet.BiomeDefinitionListPacket;
import org.cloudburstmc.protocol.bedrock.packet.CommandOutputPacket;
import org.cloudburstmc.protocol.bedrock.packet.CommandRequestPacket;
import org.cloudburstmc.protocol.bedrock.packet.ConfirmSkinPacket;
import org.cloudburstmc.protocol.bedrock.packet.ContainerOpenPacket;
import org.cloudburstmc.protocol.bedrock.packet.EventPacket;
import org.cloudburstmc.protocol.bedrock.packet.InteractPacket;
import org.cloudburstmc.protocol.bedrock.packet.MobEffectPacket;
import org.cloudburstmc.protocol.bedrock.packet.NetEaseJsonPacket;
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket;
import org.cloudburstmc.protocol.bedrock.packet.PlayerEnchantOptionsPacket;
import org.cloudburstmc.protocol.bedrock.packet.PyRpcPacket;
import org.cloudburstmc.protocol.bedrock.packet.ResourcePackStackPacket;
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket;
import org.cloudburstmc.protocol.bedrock.packet.StoreBuySuccessPacket;
import org.cloudburstmc.protocol.bedrock.packet.TextPacket;
import org.cloudburstmc.protocol.common.util.TypeMap;

import java.util.HashSet;
import java.util.Set;

/**
 * 网易 898 协议编解码器（对应 Minecraft 1.21.130）。
 *
 * <p>结构与 {@code Bedrock_v860_NetEase} 保持一致：以标准 898 codec 为基准，覆盖网易有差异的序列化器，
 * 并注册网易私有包。RakNet 协议版本固定为 8（网易客户端使用）。</p>
 *
 * <p>兼容开关：标准的 898 相对 860 改动了 StartGame、Text、命令三件套、Animate、MobEffect、Interact、Event、
 * ResourcePackStack。网易分叉若未同步这些改动，可把 {@code wire-format-898} 设为 {@code v860}，
 * 这些包会回退到 860 时代的线格式；默认仍按标准 898 走。</p>
 */
public class Bedrock_v898_NetEase extends Bedrock_v898 {
    /**
     * 网易在容器槽位枚举 17 号位置插入了 {@code RECIPE_BOOK}，标准版本没有这一项，
     * 因此之后的槽位序号整体后移一位。898 的标准槽位表与 v712 相同，可沿用同一构造方式。
     */
    protected static final TypeMap<ContainerSlotType> CONTAINER_SLOT_TYPES = Bedrock_v712.CONTAINER_SLOT_TYPES
            .toBuilder()
            .shift(17, 1)
            .insert(17, ContainerSlotType.RECIPE_BOOK)
            .build();

    /** 默认配置下的 codec，供测试与文档引用；实际注册走 {@link #createCodec(CompatSettings)}。 */
    public static final BedrockCodec CODEC = createCodec(CompatSettings.defaults());

    public static BedrockCodec createCodec(CompatSettings settings) {
        CompatSettings s = settings == null ? CompatSettings.defaults() : settings;

        BedrockCodec.Builder builder = Bedrock_v898.CODEC.toBuilder()
                .raknetProtocolVersion(8)
                .helper(() -> new BedrockCodecHelper_v898_NetEase(ENTITY_DATA, GAME_RULE_TYPES,
                        ITEM_STACK_REQUEST_TYPES, CONTAINER_SLOT_TYPES, PLAYER_ABILITIES,
                        TEXT_PROCESSING_ORIGINS, s.authInputBitmap()))
                .updateSerializer(PlayerAuthInputPacket.class, PlayerAuthInputSerializer_v766_NetEase.INSTANCE)
                .updateSerializer(PlayerEnchantOptionsPacket.class, PlayerEnchantOptionsSerializer_v407_NetEase.INSTANCE)
                .updateSerializer(BiomeDefinitionListPacket.class, BiomeDefinitionListSerializer_v860_NetEase.INSTANCE)
                .updateSerializer(ContainerOpenPacket.class, ContainerOpenSerializer_v860_NetEase.INSTANCE);

        if (s.legacyWireFormat()) {
            builder.updateSerializer(TextPacket.class, TextSerializer_v686_NetEase.INSTANCE)
                    .updateSerializer(StartGamePacket.class, StartGameSerializer_v827.INSTANCE)
                    .updateSerializer(CommandRequestPacket.class, new CommandRequestSerializer_v567())
                    .updateSerializer(CommandOutputPacket.class, CommandOutputSerializer_v291.INSTANCE)
                    .updateSerializer(AvailableCommandsPacket.class, new AvailableCommandsSerializer_v594(COMMAND_PARAMS))
                    .updateSerializer(AnimatePacket.class, AnimateSerializer_v859.INSTANCE)
                    .updateSerializer(MobEffectPacket.class, MobEffectSerializer_v748.INSTANCE)
                    .updateSerializer(InteractPacket.class, InteractSerializer_v388.INSTANCE)
                    .updateSerializer(EventPacket.class, EventSerializer_v685.INSTANCE)
                    .updateSerializer(ResourcePackStackPacket.class, ResourcePackStackSerializer_v671.INSTANCE);
        } else {
            builder.updateSerializer(TextPacket.class, TextSerializer_v898_NetEase.INSTANCE);
            // 898 标准给 AnimatePacket 增加了 swingSource 可选字符串。网易客户端未同步该字段时，
            // 一次挥臂就会让客户端读错后续包；单独回退 Animate，不影响其它 898 线格式。
            if (CompatSettings.ANIMATE_NETEASE.equals(s.animateFormat898())) {
                // 网易 898 在标准 v898 Animate 之后再追加一个 VarLong 攻击 ID。
                // 布吉岛 netease/1.21.130 的 NeteaseAnimateSerializer 就是这样实现的。
                builder.updateSerializer(AnimatePacket.class, NeteaseAnimateSerializer.INSTANCE);
            } else if (CompatSettings.ANIMATE_V291.equals(s.animateFormat898())) {
                builder.updateSerializer(AnimatePacket.class, AnimateSerializer_v291.INSTANCE);
            } else if (CompatSettings.ANIMATE_V859.equals(s.animateFormat898())) {
                builder.updateSerializer(AnimatePacket.class, AnimateSerializer_v859.INSTANCE);
            }
        }

        Set<Integer> usedIds = new HashSet<>();
        builder.registerPacket(PyRpcPacket::new, PyRpcSerializer.INSTANCE,
                privateId("py-rpc", s.pyRpcId(), 200, usedIds), PacketRecipient.BOTH);
        builder.registerPacket(StoreBuySuccessPacket::new, StoreBuySuccessSerializer.INSTANCE,
                privateId("store-buy-success", s.storeBuySuccessId(), 202, usedIds), PacketRecipient.BOTH);
        builder.registerPacket(NetEaseJsonPacket::new, NetEaseJsonSerializer.INSTANCE,
                privateId("netease-json", s.jsonId(), 203, usedIds), PacketRecipient.BOTH);
        if (s.confirmSkinEnabled()) {
            builder.registerPacket(ConfirmSkinPacket::new, ConfirmSkinSerializer.INSTANCE,
                    privateId("confirm-skin", s.confirmSkinId(), 228, usedIds), PacketRecipient.CLIENT);
        }
        return builder.build();
    }

    /**
     * 私有包 ID 过滤：必须落在 1..255、不与标准 898 包冲突、也不与本次注册的其它私有包重复。
     * 不满足时回退默认值并记录告警，避免配置笔误把标准包顶掉。
     */
    private static int privateId(String name, int candidate, int fallback, Set<Integer> used) {
        int id = CompatSettings.sanePacketId(candidate, fallback);
        boolean usable = !used.contains(id) && Bedrock_v898.CODEC.getPacketDefinition(id) == null;
        if (!usable) {
            if (NeteaseExtension.LOG != null && id != fallback) {
                NeteaseExtension.LOG.warning("[netease] 私有包 " + name + " 的 ID " + id
                        + " 不可用（与标准包或其它私有包冲突），回退为 " + fallback);
            }
            id = fallback;
        }
        used.add(id);
        return id;
    }
}