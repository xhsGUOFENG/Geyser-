/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.cloudburstmc.nbt.NbtMap;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition;
import org.cloudburstmc.protocol.common.DefinitionRegistry;
import org.geysermc.geyser.registry.type.BlockMappings;
import org.geysermc.geyser.registry.type.GeyserBedrockBlock;

import java.util.HashMap;
import java.util.Map;

/**
 * 网易 1.21.130（协议 898）要求 StartGame 使用 hashed 方块网络 ID。
 * Geyser 的 {@link BlockMappings} 是以连续运行时 ID 为下标的注册表，补丁把每个方块改写成
 * FNV-1a 哈希 ID 后，数组下标就不再等于 ID，codec 的
 * {@code DefinitionUtils.checkDefinition(helper.getBlockDefinitions(), def)} 会按
 * {@code getDefinition(def.getRuntimeId())} 做同一性校验而失败（实体搬运方块、矿车 display
 * block、UpdateBlock 等都会抛 "Definition is not registered" 并踢人）。
 *
 * <p>这个注册表只负责给 codec 用：既保留原 {@link BlockMappings} 的连续 ID 查询，也能按哈希 ID
 * 找回补丁后的同一个方块实例，从而让 hashed 模式下的序列化/反序列化都通过同一性校验。</p>
 */
public final class NeteaseBlockRegistry implements DefinitionRegistry<BlockDefinition> {

    private final BlockMappings delegate;
    private final Int2ObjectMap<GeyserBedrockBlock> byId = new Int2ObjectOpenHashMap<>();
    private final Map<NbtMap, GeyserBedrockBlock> byState = new HashMap<>();

    public NeteaseBlockRegistry(BlockMappings mappings) {
        this.delegate = mappings;
        for (int i = 0; ; i++) {
            GeyserBedrockBlock block = mappings.getDefinition(i);
            if (block == null) break;
            add(block);
        }
        // 只依赖 BlockMappings.getDefinition(int) 这个稳定接口遍历完整调色板（含 air、自定义方块）。
        // 不再调用 getCustomBlockStateDefinitions()/getExtendedCollisionBoxes() 等可选访问器：
        // 不同 Geyser 构建里这些方法可能不存在或签名不同，会直接抛 NoSuchMethodError 让登录失败。
    }

    private void add(BlockDefinition definition) {
        if (!(definition instanceof GeyserBedrockBlock block)) return;
        byId.putIfAbsent(block.getRuntimeId(), block);
        if (block.getState() != null) {
            byState.putIfAbsent(block.getState(), block);
        }
    }

    @Override
    public BlockDefinition getDefinition(int runtimeId) {
        GeyserBedrockBlock block = byId.get(runtimeId);
        if (block != null) return block;
        return delegate.getDefinition(runtimeId);
    }

    @Override
    public boolean isRegistered(BlockDefinition definition) {
        if (definition == null) return false;
        // 哈希模式下最终写到线上的只有 runtimeId；FNV-1a 32 位存在极小概率碰撞，
        // 碰撞的两个状态仍应允许序列化（否则玩家会因一个方块定义被踢），因此按 ID 是否已登记判定。
        // 这里不再回调 BlockMappings.isRegistered：不同 Geyser 构建的桥接方法签名可能不一致。
        return byId.containsKey(definition.getRuntimeId());
    }

    /**
     * Geyser 的 {@code GeyserSession.startGame()} 会再次执行
     * {@code upstream.getCodecHelper().setBlockDefinitions(this.blockMappings)}，把这里安装的
     * 注册表覆盖回按连续 ID 排布的 BlockMappings。每次发送包前调用本方法，确保编码阶段用的
     * 仍是哈希注册表，否则 SetEntityData 的 CARRY_BLOCK_STATE 仍会抛 "Definition is not registered"。
     */
    public void install(BedrockCodecHelper helper) {
        if (helper != null && helper.getBlockDefinitions() != this) {
            helper.setBlockDefinitions(this);
        }
    }

    /** 把 Geyser 的连续 ID 方块定义换成同一个 hashed 实例，供 UpdateBlock 等包使用。 */
    public BlockDefinition wrap(BlockDefinition definition) {
        if (!(definition instanceof GeyserBedrockBlock block) || block.getState() == null) {
            return definition;
        }
        GeyserBedrockBlock mapped = byState.get(block.getState());
        return mapped != null ? mapped : definition;
    }
}
