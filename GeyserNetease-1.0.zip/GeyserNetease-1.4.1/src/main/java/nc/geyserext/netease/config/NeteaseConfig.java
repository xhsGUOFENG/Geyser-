/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.config;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class NeteaseConfig {
    @JsonProperty("only-netease-clients")
    private boolean onlyNeteaseClients;
    @JsonProperty("debug-mode")
    private boolean debugMode;

    /** 攻击键排障：记录攻击相关的下行包（Animate/EntityEvent/LevelSoundEvent/SetEntityData）。只写本地日志。 */
    @JsonProperty("packet-trace-v3")
    private boolean packetTrace = false;
    @JsonProperty("disconnect-message")
    private String disconnectMessage = "This server only accepts NetEase clients.";

    /**
     * 898 的线格式：v898 = 跟随标准 1.21.130；v860 = 网易未跟进 898 改动时回退到 860 的包结构。
     */
    @JsonProperty("wire-format-898")
    private String wireFormat898 = CompatSettings.WIRE_V898;

    /**
     * AnimatePacket 的线格式：v859 不写 898 新增的 swingSource 可选字段；v898 跟随标准 1.21.130。
     * 网易客户端若未同步 swingSource，会在挥臂（攻击键）时把后续字节读错，表现为客户端报错。
     */
    @JsonProperty("animate-format-898-v4")
    private String animateFormat898 = CompatSettings.ANIMATE_NETEASE;

    /**
     * PlayerAuthInput 位图模式：netease（默认，对称且与旧版读方向一致）、standard（原版 898）、legacy（保留旧的读写不一致实现）。
     */
    @JsonProperty("auth-input-bitmap")
    private String authInputBitmap = CompatSettings.BITMAP_NETEASE;

    /** 网易私有包 ID；网易若改了 ID，可在这里覆盖。 */
    @JsonProperty("private-packet-ids")
    private PrivatePacketIds privatePacketIds = new PrivatePacketIds();

    /** 兼容旧配置字段；当前不再控制冷却。冷却显示改由 Geyser 的 show-cooldown / cooldown-type 设置决定。 */
    @JsonProperty("attack-cooldown")
    private boolean attackCooldown = true;

    /** 网易会话专用 BossBar 冷却条；不依赖客户端模组，默认开启。 */
    @JsonProperty("bossbar-cooldown")
    private boolean bossBarCooldown = true;

    /** 是否记录被丢弃的“当前 codec 不认识”的包（如 898 之后新增的 LocatorBar）。 */
    @JsonProperty("log-dropped-packets")
    private Boolean logDroppedPackets = Boolean.TRUE;

    public boolean onlyNeteaseClients() { return onlyNeteaseClients; }
    public boolean debugMode() { return debugMode; }
    public boolean packetTrace() { return packetTrace; }
    public String disconnectMessage() { return disconnectMessage; }

    public String wireFormat898() {
        if (wireFormat898 != null && CompatSettings.WIRE_V860.equalsIgnoreCase(wireFormat898.trim())) {
            return CompatSettings.WIRE_V860;
        }
        return CompatSettings.WIRE_V898;
    }

    public String animateFormat898() {
        String v = animateFormat898 == null ? "" : animateFormat898.trim().toLowerCase(java.util.Locale.ROOT);
        return switch (v) {
            case CompatSettings.ANIMATE_V898 -> CompatSettings.ANIMATE_V898;
            case CompatSettings.ANIMATE_V859 -> CompatSettings.ANIMATE_V859;
            case CompatSettings.ANIMATE_V291 -> CompatSettings.ANIMATE_V291;
            default -> CompatSettings.ANIMATE_NETEASE;
        };
    }

    public String authInputBitmap() {
        String v = authInputBitmap == null ? "" : authInputBitmap.trim().toLowerCase(java.util.Locale.ROOT);
        return switch (v) {
            case CompatSettings.BITMAP_STANDARD -> CompatSettings.BITMAP_STANDARD;
            case CompatSettings.BITMAP_LEGACY -> CompatSettings.BITMAP_LEGACY;
            default -> CompatSettings.BITMAP_NETEASE;
        };
    }

    public int pyRpcId() { return idOf(privatePacketIds == null ? null : privatePacketIds.getPyRpc(), 200); }
    public int storeBuySuccessId() { return idOf(privatePacketIds == null ? null : privatePacketIds.getStoreBuySuccess(), 202); }
    public int jsonId() { return idOf(privatePacketIds == null ? null : privatePacketIds.getJson(), 203); }
    public int confirmSkinId() { return idOf(privatePacketIds == null ? null : privatePacketIds.getConfirmSkin(), 228); }
    public boolean confirmSkinEnabled() {
        return privatePacketIds == null || privatePacketIds.isConfirmSkinEnabled();
    }
    public boolean logDroppedPackets() { return logDroppedPackets == null || logDroppedPackets; }
    public boolean attackCooldown() { return attackCooldown; }
    public boolean bossBarCooldown() { return bossBarCooldown; }

    private static int idOf(Integer value, int fallback) {
        return CompatSettings.sanePacketId(value == null ? 0 : value, fallback);
    }

    /** 私有包 ID 覆盖项。缺省值与 860 时代保持一致。 */
    public static final class PrivatePacketIds {
        @JsonProperty("py-rpc")
        private int pyRpc = 200;
        @JsonProperty("store-buy-success")
        private int storeBuySuccess = 202;
        @JsonProperty("netease-json")
        private int json = 203;
        @JsonProperty("confirm-skin")
        private int confirmSkin = 228;
        @JsonProperty("confirm-skin-enabled")
        private boolean confirmSkinEnabled = true;

        public int getPyRpc() { return pyRpc; }
        public int getStoreBuySuccess() { return storeBuySuccess; }
        public int getJson() { return json; }
        public int getConfirmSkin() { return confirmSkin; }
        public boolean isConfirmSkinEnabled() { return confirmSkinEnabled; }
    }
}