/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.config;

/**
 * 网易 898 适配的兼容性快照。
 *
 * <p>把 {@link NeteaseConfig} 里的兼容开关固化成不可变对象，供编解码器构建时使用；
 * 配置只在启动时读取一次，改动后需要重启，避免运行期重建 codec 造成会话状态不一致。</p>
 */
public record CompatSettings(
        boolean legacyWireFormat,
        String animateFormat898,
        String authInputBitmap,
        int pyRpcId,
        int storeBuySuccessId,
        int jsonId,
        int confirmSkinId,
        boolean confirmSkinEnabled,
        boolean logDroppedPackets
) {

    public static final String WIRE_V898 = "v898";
    public static final String WIRE_V860 = "v860";
    public static final String ANIMATE_V898 = "v898";
    public static final String ANIMATE_V859 = "v859";
    public static final String ANIMATE_V291 = "v291";
    public static final String ANIMATE_NETEASE = "netease";
    public static final String BITMAP_NETEASE = "netease";
    public static final String BITMAP_STANDARD = "standard";
    public static final String BITMAP_LEGACY = "legacy";

    public static CompatSettings defaults() {
        return new CompatSettings(false, ANIMATE_NETEASE, BITMAP_NETEASE, 200, 202, 203, 228, true, true);
    }

    public static CompatSettings from(NeteaseConfig config) {
        if (config == null) {
            return defaults();
        }
        return new CompatSettings(
                WIRE_V860.equalsIgnoreCase(config.wireFormat898()),
                config.animateFormat898(),
                config.authInputBitmap(),
                config.pyRpcId(),
                config.storeBuySuccessId(),
                config.jsonId(),
                config.confirmSkinId(),
                config.confirmSkinEnabled(),
                config.logDroppedPackets());
    }

    /** 私有包 ID 必须是 1..255（Bedrock 包头为单字节包 ID）。冲突时回退到默认值。 */
    public static int sanePacketId(int candidate, int fallback) {
        return candidate > 0 && candidate < 256 ? candidate : fallback;
    }
}