/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util.protocol;

import nc.geyserext.netease.NeteaseExtension;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.geysermc.geyser.network.bedrock.GameProtocol;
import org.geysermc.geyser.registry.BlockRegistries;
import org.geysermc.geyser.registry.Registries;
import org.geysermc.geyser.registry.Registry;
import org.geysermc.geyser.registry.VersionedRegistry;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 让 Geyser 2.12.x 的内部注册表认识网易的旧协议号。
 *
 * <p>2.12.1 只保留 26.40–26.63 的 ITEMS/TAGS/BLOCKS 档位，而 Geyser 的配方与背包代码会直接用
 * {@code session.getUpstream().getProtocolVersion()}（对网易客户端就是 898/860/…）去查这些注册表，
 * 于是抛出 {@code No appropriate value for version: 898}，表现为配方书、背包内容、地图等全部翻译失败——
 * 玩家能进来，但不能正常游玩。</p>
 *
 * <p>这里把每个已注册的网易协议版本都别名到最新（DEFAULT_BEDROCK_PROTOCOL）的映射上。会话自身使用的
 * BlockMappings/ItemMappings 本来就是按最新版本伪造的，因此别名与之一致。</p>
 */
public final class RegistryCompat {
    private RegistryCompat() {
    }

    public static void installAliases(Collection<Integer> versions) {
        if (versions == null || versions.isEmpty()) return;
        alias("BLOCKS", BlockRegistries.BLOCKS, versions);
        alias("ITEMS", Registries.ITEMS, versions);
        alias("TAGS", Registries.TAGS, versions);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <V> void alias(String name, VersionedRegistry<V> registry, Collection<Integer> versions) {
        try {
            V latest = registry.forVersion(GameProtocol.DEFAULT_BEDROCK_PROTOCOL);
            Field field = Registry.class.getDeclaredField("mappings");
            field.setAccessible(true);
            Map<Integer, V> mappings = (Map<Integer, V>) field.get(registry);
            int added = 0;
            for (int version : versions) {
                if (!mappings.containsKey(version)) {
                    mappings.put(version, latest);
                    added++;
                }
            }
            if (added > 0 && NeteaseExtension.LOG != null) {
                NeteaseExtension.LOG.info("[netease] 已为 " + name + " 注册表补齐协议别名 "
                        + versions + " → " + GameProtocol.DEFAULT_BEDROCK_PROTOCOL + "（新增 " + added + " 项）");
            }
        } catch (Throwable t) {
            if (NeteaseExtension.LOG != null) {
                NeteaseExtension.LOG.warning("[netease] 为 " + name + " 注册表补齐协议别名失败: " + t);
            }
        }
    }
}
