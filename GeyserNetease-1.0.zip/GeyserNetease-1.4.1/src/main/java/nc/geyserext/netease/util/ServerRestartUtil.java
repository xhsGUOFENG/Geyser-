/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.EventLoopGroup;
import io.netty.util.NettyRuntime;
import io.netty.util.concurrent.DefaultThreadFactory;
import io.netty.util.internal.SystemPropertyUtil;
import nc.geyserext.netease.initializer.NeteaseServerInitializer;
import org.cloudburstmc.netty.channel.raknet.RakChannelFactory;
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption;
import org.cloudburstmc.netty.channel.raknet.config.RakServerCookieMode;
import org.cloudburstmc.netty.handler.codec.raknet.server.RakServerOfflineHandler;
import org.geysermc.geyser.GeyserImpl;
import org.geysermc.geyser.configuration.GeyserConfig;
import org.geysermc.geyser.network.BedrockPingHandler;
import org.geysermc.geyser.network.RaknetServer;
import org.geysermc.geyser.network.bedrock.raknet.Bootstraps;
import org.geysermc.geyser.network.bedrock.raknet.RakConnectionRequestHandler;
import org.geysermc.geyser.network.bedrock.raknet.RakPingHandler;
import org.geysermc.mcprotocollib.network.helper.TransportHelper;

import java.lang.reflect.Field;
import java.net.InetSocketAddress;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static org.cloudburstmc.netty.channel.raknet.RakConstants.DEFAULT_GLOBAL_PACKET_LIMIT;
import static org.cloudburstmc.netty.channel.raknet.RakConstants.DEFAULT_PACKET_LIMIT;

/**
 * 用网易专用的 {@link NeteaseServerInitializer} 替换 Geyser 默认的 RakNet 监听器。
 *
 * <p>Geyser 2.11 起 {@code GeyserImpl.getGeyserServer()} 返回 {@link RaknetServer}
 * （final 类，内部字段私有），因此这里：先 shutdown 旧监听器，再按相同参数用
 * NetEase 初始化器重新绑定同一端口，最后把新的 EventLoop / 绑定句柄通过反射写回，
 * 保证 Geyser 后续的 shutdown / reload 仍然正常。</p>
 */
public final class ServerRestartUtil {
    private static final TransportHelper.TransportType TRANSPORT = TransportHelper.TRANSPORT_TYPE;
    /** doRestart 已经关闭旧监听器；只有该状态为 true 时才允许执行标准监听器兜底。 */
    private static volatile boolean listenerShutDown;

    private ServerRestartUtil() {
    }

    public static void restart(boolean onlyNeteaseClients) {
        listenerShutDown = false;
        try {
            doRestart(onlyNeteaseClients);
        } catch (NoClassDefFoundError e) {
            GeyserImpl.getInstance().getLogger().error(
                "[GeyserNetease] 监听器重建期间缺少类；检查是否已关闭旧监听器", e);
            if (listenerShutDown) {
                restoreStandardListener();
            }
        } catch (Throwable e) {
            // 注意：NoSuchMethodError 等属于 Error，必须用 Throwable 捕获，否则扩展会静默失效
            GeyserImpl.getInstance().getLogger().error("[GeyserNetease] Failed to restart bedrock listener", e);
            // 只有旧监听器确实已 shutdown 时才回退，避免在未关闭时重复绑定同一端口。
            if (listenerShutDown) {
                restoreStandardListener();
            }
        }
    }

    /**
     * 自定义网易监听器安装失败时的兜底：重建一个 Geyser 标准 RaknetServer 并写回 GeyserImpl。
     * 网易 RakNet 8 会因此暂时不可用，但国际版 Bedrock 不会跟着全断。
     */
    private static void restoreStandardListener() {
        try {
            GeyserImpl geyser = GeyserImpl.getInstance();
            GeyserConfig cfg = geyser.config();
            int threads = Integer.getInteger("Geyser.BedrockNetworkThreads", -1);
            if (threads == -1) {
                threads = Math.max(1,
                        SystemPropertyUtil.getInt("io.netty.eventLoopThreads", NettyRuntime.availableProcessors() * 2));
            }
            RaknetServer standard = new RaknetServer(geyser, threads);
            CompletableFuture<Void> bind = standard.bind(
                new InetSocketAddress(cfg.bedrock().address(), cfg.bedrock().raknetPort()));
            try {
                bind.get(10, TimeUnit.SECONDS);
            } catch (TimeoutException e) {
                bind.cancel(true);
                standard.shutdown();
                throw new IllegalStateException("标准 RakNet 监听器绑定超时（10s）", e);
            } catch (Exception e) {
                standard.shutdown();
                throw new IllegalStateException("标准 RakNet 监听器绑定失败", e);
            }
            Field field = GeyserImpl.class.getDeclaredField("geyserServer");
            field.setAccessible(true);
            field.set(geyser, standard);
            listenerShutDown = false;
            geyser.getLogger().warning("[GeyserNetease] 已回退到 Geyser 标准 RakNet 监听器；"
                    + "国际版已恢复，网易入口本轮不可用，请检查启动日志。");
        } catch (Throwable fallbackFailure) {
            GeyserImpl.getInstance().getLogger().error(
                    "[GeyserNetease] 标准监听器回退也失败，Bedrock 入口当前不可用", fallbackFailure);
        }
    }

    private static void doRestart(boolean onlyNeteaseClients) throws Exception {
        GeyserImpl geyser = GeyserImpl.getInstance();
        RaknetServer server = geyser.getGeyserServer();
        if (server == null) {
            geyser.getLogger().warning("[GeyserNetease] RakNet server not started yet; NetEase listener was not installed.");
            return;
        }
        // 先确认 2.12.x 的内部字段仍在：字段改名时宁可保留 Geyser 原监听器（国际版仍可进），
        // 也不要在 shutdown 之后才失败，导致所有 Bedrock 连接一起断掉。
        for (String field : RAKNET_REFLECTION_FIELDS) {
            if (!hasField(field)) {
                geyser.getLogger().warning("[GeyserNetease] RaknetServer 字段 " + field
                        + " 不存在（Geyser 版本不兼容），保留原监听器；本次不启用 NetEase 专用监听。");
                return;
            }
        }
        // 先标记为已关闭：即使 shutdown 自身抛错，也要让兜底逻辑尝试恢复监听器。
        listenerShutDown = true;
        server.shutdown();

        int bedrockThreadCount = Integer.getInteger("Geyser.BedrockNetworkThreads", -1);
        if (bedrockThreadCount == -1) {
            bedrockThreadCount = Math.max(1,
                SystemPropertyUtil.getInt("io.netty.eventLoopThreads", NettyRuntime.availableProcessors() * 2));
        }

        int listenCount = Bootstraps.isReusePortAvailable() ? Integer.getInteger("Geyser.ListenCount", 1) : 1;
        EventLoopGroup group = TRANSPORT.eventLoopGroupFactory()
            .apply(listenCount, new DefaultThreadFactory("GeyserServer", true));
        EventLoopGroup childGroup = TRANSPORT.eventLoopGroupFactory()
            .apply(bedrockThreadCount, new DefaultThreadFactory("GeyserServerChild", true));

        GeyserConfig cfg = geyser.config();
        boolean rakCookie = Boolean.parseBoolean(System.getProperty("Geyser.RakSendCookie", "true"));

        // 2.12.1 起 HAPROXY 由白名单列表决定（useHaproxyProtocol() 已移除）；空列表表示不启用。
        java.util.List<String> haproxyWhitelist = cfg.advanced().bedrock().haproxyProtocolWhitelistedIps();
        boolean proxied = haproxyWhitelist != null
                && haproxyWhitelist.stream().anyMatch(entry -> entry != null && !entry.isBlank());

        NeteaseServerInitializer initializer = new NeteaseServerInitializer(geyser, rakCookie, onlyNeteaseClients);

        BedrockPingHandler pingResponder = new BedrockPingHandler(geyser);
        RakConnectionRequestHandler connectionHandler = new RakConnectionRequestHandler(server);
        RakPingHandler pingHandler = new RakPingHandler(pingResponder);

        ServerBootstrap bootstrap = new ServerBootstrap()
            .channelFactory(RakChannelFactory.server(TRANSPORT.datagramChannelClass()))
            .group(group, childGroup)
            .option(RakChannelOption.RAK_HANDLE_PING, true)
            .option(RakChannelOption.RAK_MAX_MTU, cfg.advanced().bedrock().mtu())
            .option(RakChannelOption.RAK_PACKET_LIMIT, positiveProp("Geyser.RakPacketLimit", DEFAULT_PACKET_LIMIT))
            .option(RakChannelOption.RAK_GLOBAL_PACKET_LIMIT, positiveProp("Geyser.RakGlobalPacketLimit", DEFAULT_GLOBAL_PACKET_LIMIT))
            .option(RakChannelOption.RAK_SERVER_COOKIE_MODE,
                rakCookie ? RakServerCookieMode.ACTIVE : RakServerCookieMode.INVALID)
            .option(RakChannelOption.RAK_PROXY_PROTOCOL, proxied)
            .childHandler(initializer);
        // 注意：2.12.1 的 Geyser 监听器把 RAK_SUPPORTED_PROTOCOLS 限制为 {11}；
        // 网易客户端走 RakNet 8，这里必须保持不限制（null），否则握手阶段就会被拒。
        Bootstraps.setupBootstrap(bootstrap, TRANSPORT);

        ChannelFuture[] futures = new ChannelFuture[listenCount];
        InetSocketAddress bindAddress = new InetSocketAddress(cfg.bedrock().address(), cfg.bedrock().raknetPort());
        for (int i = 0; i < listenCount; i++) {
            ChannelFuture future = bootstrap.bind(bindAddress);
            future.addListener((ChannelFutureListener) f -> {
                if (!f.isSuccess()) {
                    return;
                }
                Channel channel = f.channel();
                channel.pipeline()
                    .addBefore(RakServerOfflineHandler.NAME, RakConnectionRequestHandler.NAME, connectionHandler)
                    .addAfter(RakServerOfflineHandler.NAME, RakPingHandler.NAME, pingHandler);
            });
            futures[i] = future;
        }
        Bootstraps.allOf(futures).join();

        // 把新的 EventLoop 与绑定句柄写回 Geyser 的 RaknetServer 实例
        setField("group", server, group);
        setField("childGroup", server, childGroup);
        setField("playerGroup", server, initializer.getEventLoopGroup());
        setField("bootstrapFutures", server, futures);

        geyser.getLogger().info("[GeyserNetease] NetEase RakNet listener installed (port "
            + cfg.bedrock().raknetPort() + ").");
    }

    private static final String[] RAKNET_REFLECTION_FIELDS = {"group", "childGroup", "playerGroup", "bootstrapFutures"};

    private static boolean hasField(String name) {
        try {
            RaknetServer.class.getDeclaredField(name);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 逐项写回；单个字段失败只告警，不影响已经建立的新监听器。 */
    private static void setField(String name, Object target, Object value) {
        try {
            Field field = RaknetServer.class.getDeclaredField(name);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Throwable t) {
            GeyserImpl.getInstance().getLogger().warning("[GeyserNetease] 写回 RaknetServer." + name
                    + " 失败: " + t + "（监听器已建立，但 Geyser 的重载/关服可能不完整）");
        }
    }

    private static int positiveProp(String property, int defaultValue) {
        String value = System.getProperty(property);
        try {
            int parsed = value != null ? Integer.parseInt(value) : defaultValue;
            return Math.max(parsed, 1);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
}
