/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition;
import org.cloudburstmc.protocol.bedrock.data.inventory.CreativeItemData;
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData;
import org.geysermc.geyser.registry.type.ItemMapping;
import org.geysermc.geyser.registry.type.ItemMappings;
import sun.misc.Unsafe;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * 网易 898 的 StartGame 使用 hashed 方块网络 ID（{@code blockNetworkIdsHashed=true}）。
 * Geyser 的全局物品表 {@code Registries.ITEMS} 里的方块定义仍指向连续运行时 ID。
 * 客户端收到的物品栈因此携带连续 ID，而方块调色板已经是哈希 ID，导致手持方块无法映射，
 * 表现为“放不下去”，并在本地生成幽灵方块，随后被服务端位置校正拉回。
 *
 * <p>不同 Geyser 构建的 {@link ItemMappings} 字段/访问器可能不同（例如某些版本没有
 * {@code getLightBlocks()}）。这里不调用任何可选 getter 或 builder，而是用 Unsafe 复制
 * 字段后逐个替换，缺失字段直接跳过，避免运行期 {@code NoSuchMethodError} 把登录会话踢掉。</p>
 */
public final class NeteaseItemMappings {

    private static final Unsafe U;

    static {
        try {
            Field f = Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            U = (Unsafe) f.get(null);
        } catch (Throwable e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private NeteaseItemMappings() {
    }

    public static ItemMappings rewrite(ItemMappings source, NeteaseBlockRegistry blocks) {
        if (source == null || blocks == null) {
            return source;
        }
        List<String> failures = new ArrayList<>();
        try {
            ItemMappings copy = copyInstance(source, ItemMappings.class);
            if (copy == null) {
                logError("ItemMappings 复制失败，物品表保持原样", null);
                return source;
            }

            Object rawItems = getField(source, "items");
            if (rawItems instanceof ItemMapping[] items) {
                ItemMapping[] rewritten = new ItemMapping[items.length];
                for (int i = 0; i < items.length; i++) {
                    rewritten[i] = rewriteMapping(items[i], blocks, failures, "items[" + i + "]");
                }
                if (!setField(copy, "items", rewritten)) {
                    failures.add("items 字段写回失败");
                }
            } else {
                failures.add("items 字段缺失或类型不符");
            }

            if (!setField(copy, "lodestoneCompass",
                    rewriteMapping((ItemMapping) getField(source, "lodestoneCompass"), blocks,
                            failures, "lodestoneCompass"))) {
                failures.add("lodestoneCompass 字段写回失败");
            }
            setField(copy, "cachedJavaMappings", new WeakHashMap<>());

            Object rawLightBlocks = getField(source, "lightBlocks");
            if (rawLightBlocks instanceof Int2ObjectMap<?> lightBlocks) {
                try {
                    Int2ObjectMap<ItemMapping> rewritten = new Int2ObjectOpenHashMap<>();
                    for (Int2ObjectMap.Entry<?> entry : lightBlocks.int2ObjectEntrySet()) {
                        if (entry.getValue() instanceof ItemMapping mapping) {
                            rewritten.put(entry.getIntKey(),
                                    rewriteMapping(mapping, blocks, failures, "lightBlocks[" + entry.getIntKey() + "]"));
                        }
                    }
                    if (!setField(copy, "lightBlocks", rewritten)) {
                        failures.add("lightBlocks 字段写回失败");
                    }
                } catch (Throwable t) {
                    failures.add("lightBlocks: " + t.getClass().getSimpleName());
                }
            }

            Object rawCreative = getField(source, "creativeItems");
            if (rawCreative instanceof List<?> creativeItems) {
                List<CreativeItemData> rewritten = new ArrayList<>(creativeItems.size());
                for (Object entry : creativeItems) {
                    if (entry instanceof CreativeItemData data) {
                        rewritten.add(rewriteCreative(data, blocks, failures));
                    } else if (entry != null) {
                        rewritten.add((CreativeItemData) entry);
                    }
                }
                if (!setField(copy, "creativeItems", rewritten)) {
                    failures.add("creativeItems 字段写回失败");
                }
            }

            Object rawStored = getField(source, "storedItems");
            if (rawStored instanceof org.geysermc.geyser.inventory.item.StoredItemMappings stored) {
                if (!setField(copy, "storedItems", rewriteStored(stored, blocks, failures))) {
                    failures.add("storedItems 字段写回失败");
                }
            }

            if (!failures.isEmpty()) {
                logWarning("NeteaseItemMappings 有 " + failures.size()
                        + " 个条目/字段回退，首项: " + failures.get(0));
            }
            return copy;
        } catch (Throwable t) {
            // 只有复制容器本身失败才整体回退；单个条目失败已在下面按项处理并记录。
            logError("NeteaseItemMappings 整体重写失败，保持原物品表", t);
            return source;
        }
    }

    private static ItemMapping rewriteMapping(ItemMapping mapping, NeteaseBlockRegistry blocks,
                                              List<String> failures, String where) {
        if (mapping == null) {
            return null;
        }
        try {
            Object old = getField(mapping, "bedrockBlockDefinition");
            if (!(old instanceof BlockDefinition definition)) {
                return mapping;
            }
            BlockDefinition wrapped = blocks.wrap(definition);
            if (wrapped == definition) {
                return mapping;
            }
            ItemMapping copy = copyInstance(mapping, ItemMapping.class);
            if (copy == null) {
                failures.add(where + ": ItemMapping 复制失败");
                return mapping;
            }
            if (!setField(copy, "bedrockBlockDefinition", wrapped)) {
                failures.add(where + ": bedrockBlockDefinition 写回失败");
                return mapping;
            }
            return copy;
        } catch (Throwable t) {
            failures.add(where + ": " + t.getClass().getSimpleName());
            return mapping;
        }
    }

    private static CreativeItemData rewriteCreative(CreativeItemData entry, NeteaseBlockRegistry blocks,
                                                    List<String> failures) {
        if (entry == null) {
            return null;
        }
        try {
            ItemData item = entry.getItem();
            if (item == null) {
                failures.add("creativeItems: item 为 null");
                return entry;
            }
            BlockDefinition old = item.getBlockDefinition();
            if (old == null) {
                return entry;
            }
            BlockDefinition wrapped = blocks.wrap(old);
            if (wrapped == old) {
                return entry;
            }
            ItemData rewritten = copyInstance(item, item.getClass());
            if (rewritten == null) {
                failures.add("creativeItems: ItemData 复制失败");
                return entry;
            }
            if (!setField(rewritten, "blockDefinition", wrapped)) {
                failures.add("creativeItems: blockDefinition 写回失败");
                return entry;
            }
            CreativeItemData copy = copyInstance(entry, CreativeItemData.class);
            if (copy == null) {
                failures.add("creativeItems: CreativeItemData 复制失败");
                return entry;
            }
            if (!setField(copy, "item", rewritten)) {
                failures.add("creativeItems: item 写回失败");
                return entry;
            }
            return copy;
        } catch (Throwable t) {
            failures.add("creativeItems: " + t.getClass().getSimpleName());
            return entry;
        }
    }

    private static org.geysermc.geyser.inventory.item.StoredItemMappings rewriteStored(
            org.geysermc.geyser.inventory.item.StoredItemMappings stored, NeteaseBlockRegistry blocks,
            List<String> failures) {
        try {
            Object copy = copyInstance(stored, stored.getClass());
            if (copy == null) {
                failures.add("storedItems: 复制失败");
                return stored;
            }
            for (Field field : stored.getClass().getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers()) || field.getType() != ItemMapping.class) {
                    continue;
                }
                Object value = getField(stored, field.getName());
                if (value instanceof ItemMapping mapping) {
                    if (!setField(copy, field.getName(),
                            rewriteMapping(mapping, blocks, failures, "storedItems." + field.getName()))) {
                        failures.add("storedItems." + field.getName() + ": 写回失败");
                    }
                }
            }
            return (org.geysermc.geyser.inventory.item.StoredItemMappings) copy;
        } catch (Throwable t) {
            failures.add("storedItems: " + t.getClass().getSimpleName());
            return stored;
        }
    }

    private static void logWarning(String message) {
        try {
            if (nc.geyserext.netease.NeteaseExtension.LOG != null) {
                nc.geyserext.netease.NeteaseExtension.LOG.warning(message);
            } else {
                System.err.println(message);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void logError(String message, Throwable t) {
        try {
            if (nc.geyserext.netease.NeteaseExtension.LOG != null) {
                if (t == null) nc.geyserext.netease.NeteaseExtension.LOG.error(message);
                else nc.geyserext.netease.NeteaseExtension.LOG.error(message, t);
            } else {
                System.err.println(message + (t == null ? "" : ": " + t));
            }
        } catch (Throwable ignored) {
        }
    }

    private static <T> T copyInstance(Object source, Class<T> type) {
        try {
            T copy = type.cast(U.allocateInstance(type));
            for (Field field : type.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                long offset = U.objectFieldOffset(field);
                Class<?> fieldType = field.getType();
                if (fieldType.isPrimitive()) {
                    if (fieldType == boolean.class) U.putBoolean(copy, offset, U.getBoolean(source, offset));
                    else if (fieldType == byte.class) U.putByte(copy, offset, U.getByte(source, offset));
                    else if (fieldType == short.class) U.putShort(copy, offset, U.getShort(source, offset));
                    else if (fieldType == char.class) U.putChar(copy, offset, U.getChar(source, offset));
                    else if (fieldType == int.class) U.putInt(copy, offset, U.getInt(source, offset));
                    else if (fieldType == long.class) U.putLong(copy, offset, U.getLong(source, offset));
                    else if (fieldType == float.class) U.putFloat(copy, offset, U.getFloat(source, offset));
                    else if (fieldType == double.class) U.putDouble(copy, offset, U.getDouble(source, offset));
                } else {
                    U.putObject(copy, offset, U.getObject(source, offset));
                }
            }
            return copy;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static Object getField(Object target, String name) {
        try {
            Field field = findField(target.getClass(), name);
            if (field == null) {
                return null;
            }
            return U.getObject(target, U.objectFieldOffset(field));
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static boolean setField(Object target, String name, Object value) {
        try {
            Field field = findField(target.getClass(), name);
            if (field == null) {
                return false;
            }
            U.putObject(target, U.objectFieldOffset(field), value);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static Field findField(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }
}
