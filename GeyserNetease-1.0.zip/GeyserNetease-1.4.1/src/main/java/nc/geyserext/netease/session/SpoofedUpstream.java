/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.session;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import nc.geyserext.netease.NeteaseExtension;
import org.cloudburstmc.nbt.NbtMap;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.codec.BedrockPacketSerializer;
import org.cloudburstmc.protocol.bedrock.codec.v332.serializer.LevelSoundEventSerializer_v332;
import org.cloudburstmc.protocol.bedrock.data.SoundEvent;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityEventType;
import org.cloudburstmc.protocol.common.util.TypeMap;
import org.cloudburstmc.protocol.bedrock.BedrockServerSession;
import org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition;
import org.cloudburstmc.protocol.bedrock.data.skin.SerializedSkin;
import org.cloudburstmc.protocol.bedrock.packet.*;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.geysermc.geyser.registry.type.BlockMappings;
import org.geysermc.geyser.registry.type.GeyserBedrockBlock;
import org.geysermc.geyser.session.UpstreamSession;
import sun.misc.Unsafe;
import java.lang.reflect.Field;
import java.util.*;

public class SpoofedUpstream extends UpstreamSession {

    /** Geyser 扩展命令的根命令名；网易客户端会把命令补全渲染成 "geyser:xxx" 提示，需要从下发的命令表里剔除。 */
    private static final String GEYSER_COMMAND_ROOT = "geyser";

    /**
     * Geyser 用 TIP 类型的 TextPacket 向客户端"隐藏"地传 JSON UI 数据（<code>GeyserSession#sendJsonUIData</code>
     * 拼出 "geyseropt:cooldown:non"），依赖 Geyser 集成资源包里改过的 hud_screen.json 把它解析成冷却指示器。
     * 网易客户端不加载 / 不认这套 JSON UI 补丁，会把这串文本直接显示在屏幕上，因此在下发前丢弃。
     */
    private static final String GEYSER_UI_TEXT_PREFIX = "geyseropt:";
    /** Geyser 标准冷却的 JSON UI 数据键；它需要保留，否则标准 CooldownUtils 会被完全静默。 */
    private static final String GEYSER_COOLDOWN_UI_PREFIX = "geyseropt:cooldown:";

    private final UpstreamSession real;
    private final int[] rtToHash;
    private final boolean[] hValid;
    private nc.geyserext.netease.util.NeteaseBlockRegistry blockRegistry;
    private final boolean hashing;
    private final long neteaseUid;
    private boolean skinConfirmed;
    /** 延迟到 StartGame 之后发送的包；必须仍走本类的过滤/重写，不能直接塞给 real。 */
    private final java.util.Deque<BedrockPacket> queuedPostStartGame = new java.util.ArrayDeque<>();

    public SpoofedUpstream(UpstreamSession real, BedrockServerSession s,
            int[] rt, boolean[] hv, boolean hashing, long neteaseUid) {
        super(s);
        this.real = real;
        this.rtToHash = rt;
        this.hValid = hv;
        this.hashing = hashing;
        this.neteaseUid = neteaseUid;
    }

    public void setBlockRegistry(nc.geyserext.netease.util.NeteaseBlockRegistry registry) {
        this.blockRegistry = registry;
        ensureBlockRegistry();
    }

    private void ensureBlockRegistry() {
        if (blockRegistry == null) return;
        try {
            blockRegistry.install(real.getCodecHelper());
        } catch (Throwable ignored) {
        }
    }

    @Override public void disconnect(String r) { real.disconnect(r); }
    @Override public BedrockServerSession getSession() { return real.getSession(); }
    @Override public boolean isClosed() { return real.isClosed(); }

    private long traceSeq;

    /**
     * packet-trace 诊断：只记录攻击相关的下行包，给出动作/类型、实际序列化器和编码后字节数。
     * 直接写 INFO，不走 {@link NeteaseExtension#debug}，避免进入上传/诊断日志。
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private void traceOutgoing(BedrockPacket p) {
        if (!NeteaseExtension.packetTrace()) return;
        String detail = null;
        if (p instanceof AnimatePacket a) {
            detail = "Animate action=" + a.getAction() + " eid=" + a.getRuntimeEntityId()
                    + " data=" + a.getData() + " swingSource=" + a.getSwingSource();
        } else if (p instanceof EntityEventPacket e) {
            if (e.getType() == EntityEventType.ATTACK_START
                    || e.getType() == EntityEventType.HURT) {
                detail = "EntityEvent type=" + e.getType() + " eid=" + e.getRuntimeEntityId();
            }
        } else if (p instanceof LevelSoundEventPacket s) {
            String sound = s.getSound() == null ? "null" : s.getSound().name();
            if (sound.contains("ATTACK") || sound.contains("HURT")) {
                detail = "LevelSound sound=" + sound + " id=" + s.getIdentifier()
                        + " extra=" + s.getExtraData();
            }
        } else if (p instanceof SetEntityDataPacket d) {
            StringBuilder sb = new StringBuilder("SetEntityData eid=").append(d.getRuntimeEntityId()).append(" meta=");
            int n = 0;
            for (Map.Entry<org.cloudburstmc.protocol.bedrock.data.entity.EntityDataType<?>, Object> e
                    : d.getMetadata().entrySet()) {
                if (n++ >= 8) { sb.append("..."); break; }
                Object v = e.getValue();
                sb.append(e.getKey().getTypeName()).append('=');
                sb.append(v instanceof BlockDefinition bd ? ("block#" + bd.getRuntimeId()) : v).append(';');
            }
            detail = sb.toString();
        }
        if (detail == null) return;
        NeteaseExtension.LOG.info("[packet-trace] #" + (++traceSeq) + " " + detail
                + " serializer=" + serializerName(p) + " bytes=" + encodedSize(p));
    }

    private String serializerName(BedrockPacket p) {
        try {
            BedrockServerSession s = real.getSession();
            BedrockCodec codec = s == null ? null : s.getCodec();
            var def = codec == null ? null : codec.getPacketDefinition(p.getClass());
            return def == null ? "no-def" : def.getSerializer().getClass().getSimpleName();
        } catch (Throwable t) {
            return "?";
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private String encodedSize(BedrockPacket p) {
        try {
            BedrockServerSession s = real.getSession();
            BedrockCodec codec = s == null ? null : s.getCodec();
            if (codec == null) return "no-codec";
            var def = codec.getPacketDefinition(p.getClass());
            if (def == null) return "no-def";
            ByteBuf buffer = Unpooled.buffer();
            try {
                ((BedrockPacketSerializer) def.getSerializer()).serialize(buffer, real.getCodecHelper(), p);
                return Integer.toString(buffer.readableBytes());
            } finally {
                buffer.release();
            }
        } catch (Throwable t) {
            return "FAIL:" + t.getClass().getSimpleName() + ":" + t.getMessage();
        }
    }

    @Override public void sendPacket(BedrockPacket p) {
        ensureBlockRegistry();
        traceOutgoing(p);
        if (skipUnknownPacket(p)) return;
        if (dropUnsupportedSound(p)) return;
        if (dropUnsupportedEntityEvent(p)) return;
        if (dropGeyserUiText(p)) return;
        stripGeyserCommands(p);
        real.sendPacket(rewrite(p));
        hook(p, false);
    }

    @Override public void sendPacketImmediately(BedrockPacket p) {
        ensureBlockRegistry();
        traceOutgoing(p);
        if (skipUnknownPacket(p)) return;
        if (dropUnsupportedSound(p)) return;
        if (dropUnsupportedEntityEvent(p)) return;
        if (dropGeyserUiText(p)) return;
        stripGeyserCommands(p);
        real.sendPacketImmediately(rewrite(p));
        hook(p, true);
    }

    @Override public void queuePostStartGamePacket(BedrockPacket p) {
        queuedPostStartGame.add(p);
    }

    @Override public void sendPostStartGamePackets() {
        if (isClosed()) {
            queuedPostStartGame.clear();
            return;
        }
        BedrockPacket p;
        while ((p = queuedPostStartGame.poll()) != null) {
            sendPacket(p);
        }
        // 注入 SpoofedUpstream 之前，Geyser 可能已把少量包排进原 UpstreamSession 的队列；
        // 这里补一次 drain，避免这些包因为覆盖了发送入口而永久丢失。
        try {
            real.sendPostStartGamePackets();
        } catch (Throwable ignored) {
        }
    }

    /** 已警告过"当前 codec 不认识"的包类型，避免同类包把日志刷爆。 */
    private final Set<Class<?>> unknownPacketWarned = new HashSet<>();

    /**
     * 898 尚未定义、只在 26.x 引入的包。它们对 1.21.130 客户端没有意义，只能丢弃；
     * 列出具体原因，避免和“扩展漏注册”混为一谈。
     */
    private static final Map<String, String> KNOWN_NEWER_PACKETS = new HashMap<>();

    static {
        KNOWN_NEWER_PACKETS.put("LocatorBarPacket", "26.x 新增的定位条/路径点，1.21.130 客户端不支持");
        KNOWN_NEWER_PACKETS.put("VoxelShapesPacket", "26.x 新增的体素形状表，1.21.130 客户端不需要");
        KNOWN_NEWER_PACKETS.put("ClientboundUpdateSoundDataPacket", "26.40 的唱片句柄更新，898 走旧的 LevelSoundEvent 路径");
        KNOWN_NEWER_PACKETS.put("RecordStartedPacket", "26.40 的唱片播放句柄，898 走旧的 LevelSoundEvent 路径");
        KNOWN_NEWER_PACKETS.put("PartyChangedPacket", "26.10 新增的组队通知，898 无此包");
        KNOWN_NEWER_PACKETS.put("ClientboundDataDrivenUIShowScreenPacket", "26.30 新增的数据驱动 UI，898 无此包");
        KNOWN_NEWER_PACKETS.put("ClientboundDataDrivenUICloseScreenPacket", "26.30 新增的数据驱动 UI，898 无此包");
        KNOWN_NEWER_PACKETS.put("ClientboundDataDrivenUIReloadPacket", "26.30 新增的数据驱动 UI，898 无此包");
        KNOWN_NEWER_PACKETS.put("ClientboundTextureShiftPacket", "26.x 新增的贴图偏移，898 无此包");
        KNOWN_NEWER_PACKETS.put("CameraSplinePacket", "26.x 新增的相机样条，898 无此包");
        KNOWN_NEWER_PACKETS.put("ClientboundAttributeLayerSyncPacket", "26.x 新增的属性层同步，898 无此包");
        KNOWN_NEWER_PACKETS.put("SetPlayerFurnaceOptionsPacket", "26.x 新增的熔炉界面选项，898 无此包");
        KNOWN_NEWER_PACKETS.put("SyncWorldClocksPacket", "26.x 新增的世界时钟同步，898 无此包");
    }

    /** 已经告警过的“当前 codec 没有 ID”的音效，避免每条声音刷日志。 */
    private final Set<SoundEvent> unsupportedSoundWarned = new HashSet<>();

    /**
     * Geyser 2.12.1 会发出 26.x 才有的音效（例如 ABSORB_BLOCK），而 898 codec 的 SOUND_EVENTS 里没有这些 ID。
     * 直接发送会在编码阶段抛 {@code No id found for ...} 并踢掉玩家；这里在下发前丢弃并说明原因。
     */
    private boolean dropUnsupportedSound(BedrockPacket p) {
        if (!(p instanceof LevelSoundEventPacket soundPacket)) return false;
        BedrockServerSession s = real.getSession();
        if (s == null) return false;
        try {
            BedrockCodec codec = s.getCodec();
            if (codec == null) return false;
            var definition = codec.getPacketDefinition(LevelSoundEventPacket.class);
            if (definition == null) return false;
            if (definition.getSerializer() instanceof LevelSoundEventSerializer_v332 serializer) {
                serializer.getTypeMap().getId(soundPacket.getSound()); // 缺 ID 时抛 IllegalArgumentException
            }
            return false;
        } catch (IllegalArgumentException missingId) {
            SoundEvent sound = soundPacket.getSound();
            if (unsupportedSoundWarned.add(sound)) {
                NeteaseExtension.LOG.warning("[netease] 客户端不支持音效 " + sound
                        + "，已跳过该 LevelSoundEvent（避免编码失败断开连接）");
            }
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    /** 已经告警过的“当前 codec 没有 ID”的实体事件。 */
    private final Set<Object> unsupportedEntityEventsWarned = new HashSet<>();
    /** 序列化器 class → 其 TypeMap 字段，避免每次发包都反射查找。 */
    private final Map<Class<?>, Field> typeMapFieldCache = new HashMap<>();

    /**
     * 与音效同理：26.x 新增的 EntityEventType（例如 v975 的 HURT_WITHOUT_RECEIVING_DAMAGE）
     * 在 898 codec 里没有 ID，直接发会在编码阶段抛异常并踢人。这里只丢弃未知类型。
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private boolean dropUnsupportedEntityEvent(BedrockPacket p) {
        if (!(p instanceof EntityEventPacket event)) return false;
        BedrockServerSession s = real.getSession();
        if (s == null) return false;
        try {
            BedrockCodec codec = s.getCodec();
            if (codec == null) return false;
            var definition = codec.getPacketDefinition(EntityEventPacket.class);
            if (definition == null) return false;
            Object serializer = definition.getSerializer();
            Field field = typeMapField(serializer.getClass());
            if (field == null) return false;
            TypeMap typeMap = (TypeMap) field.get(serializer);
            typeMap.getId(event.getType()); // 缺 ID 时抛 IllegalArgumentException
            return false;
        } catch (IllegalArgumentException missingId) {
            EntityEventType type = event.getType();
            if (unsupportedEntityEventsWarned.add(type)) {
                NeteaseExtension.LOG.warning("[netease] 客户端不支持实体事件 " + type
                        + "，已跳过该 EntityEvent（避免编码失败断开连接）");
            }
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private Field typeMapField(Class<?> serializerClass) {
        Field cached = typeMapFieldCache.get(serializerClass);
        if (cached != null) return cached;
        for (Class<?> c = serializerClass; c != null; c = c.getSuperclass()) {
            for (Field field : c.getDeclaredFields()) {
                if (TypeMap.class.isAssignableFrom(field.getType())) {
                    field.setAccessible(true);
                    typeMapFieldCache.put(serializerClass, field);
                    return field;
                }
            }
        }
        return null;
    }

    /**
     * 双保险：正常情况下 {@link #getProtocolVersion()} 直接取真实 codec 版本，Geyser 不会发当前
     * codec 里没有的包。但若将来 Geyser 换版本、或某个包没在网易 codec 中注册，
     * 编码阶段会抛 {@code NullPointerException: getPacketDefinition(...) is null} 并直接踢掉玩家
     * （表现为 "Exception caught in session of ..."，随后与 Java 服断开）。
     * 这类包不能硬发，只能跳过并记一条日志，保证玩家还能继续游玩。
     */
    private boolean skipUnknownPacket(BedrockPacket p) {
        BedrockServerSession s = real.getSession();
        if (s == null) return false;
        BedrockCodec codec;
        try {
            codec = s.getCodec();
        } catch (Throwable t) {
            // 2.12 起会话断开后 channel pipeline 可能已经移除 BedrockPacketCodec，
            // 此时 getCodec() 会抛 NPE；按“连接已关闭”处理，直接放弃发送。
            NeteaseExtension.debug("[netease] codec 已移除，跳过发送: " + p.getClass().getSimpleName());
            return true;
        }
        if (codec == null) return true; // 没有 codec 时不能继续发包，按已关闭处理
        if (codec.getPacketDefinition(p.getClass()) != null) return false;
        String name = p.getClass().getSimpleName();
        if (unknownPacketWarned.add(p.getClass())) {
            String reason = KNOWN_NEWER_PACKETS.getOrDefault(name,
                    "本扩展使用的协议库没有注册该包（Geyser 版本比扩展新）");
            String line = "[netease] 已跳过 " + name + "：协议 v" + codec.getProtocolVersion()
                    + " 未定义该包，" + reason;
            boolean verbose = NeteaseExtension.CONFIG == null || NeteaseExtension.CONFIG.logDroppedPackets();
            if (verbose && NeteaseExtension.LOG != null) {
                NeteaseExtension.LOG.warning(line);
            } else {
                NeteaseExtension.debug(line);
            }
        }
        NeteaseExtension.debug("[netease] 已跳过未注册包: " + name);
        return true;
    }

    /**
     * 网易客户端不使用标准 Bedrock 的命令补全表：<code>AvailableCommandsPacket</code> 里由
     * Geyser 扩展导出的 <code>geyser</code> 根命令（help/list/quickactions 等）会在玩家点击屏幕时
     * 以 "geyser:xxx" 的形式弹在聊天栏下方。这里在下发前把该根命令剔除，Java 服务器的原生命令保持不变。
     */
    private static void stripGeyserCommands(BedrockPacket p) {
        if (p instanceof AvailableCommandsPacket available) {
            int before = available.getCommands().size();
            available.getCommands().removeIf(command -> GEYSER_COMMAND_ROOT.equals(command.getName()));
            int removed = before - available.getCommands().size();
            if (removed > 0) {
                NeteaseExtension.debug("[netease] 已从 AvailableCommandsPacket 移除 " + removed + " 个 geyser 命令，剩余 "
                    + available.getCommands().size() + " 个");
            }
        }
    }

    /**
     * 丢弃 Geyser 用来驱动 JSON UI 的 TIP 文本（如 <code>geyseropt:cooldown:non</code>）。
     * 网易客户端通常会把这些文本原样渲染出来；标准冷却的 cooldown 子键例外，
     * 由下游的冷却显示逻辑消费，不能在这里丢弃。
     */
    private static boolean dropGeyserUiText(BedrockPacket p) {
        if (!(p instanceof TextPacket text)) return false;
        if (text.getType() != TextPacket.Type.TIP) return false;
        String message = text.getMessage();
        if (message == null || !message.startsWith(GEYSER_UI_TEXT_PREFIX)) return false;
        // 标准冷却通过 geyseropt:cooldown:* 驱动集成资源包；丢掉它会让普通基岩版冷却
        // 在网易会话中永远不可见。其它 geyseropt 文本仍丢弃，避免网易客户端直接显示原始 JSON UI 串。
        if (message.startsWith(GEYSER_COOLDOWN_UI_PREFIX)) return false;
        NeteaseExtension.debug("[netease] 已丢弃 JSON UI 文本: " + message);
        return true;
    }

    private BedrockPacket rewrite(BedrockPacket p) {
        if (!hashing) return p;
        if (p instanceof UpdateBlockPacket ub) ub.setDefinition(wrapDef(ub.getDefinition()));
        else if (p instanceof StartGamePacket sg) rewriteStartGame(sg);
        return p;
    }

    private void hook(BedrockPacket p, boolean immediate) {
        if (!hashing) return;
        // 注意：这里刻意不再在 StartGame 时发“空占位”ConfirmSkin。
        // ConfirmSkinSerializer 会对 uuid / skinBytes / geoStr 做 checkNotNull，
        // 早期实现只填了 valid + uidStr，编码阶段必然抛异常，导致网易客户端等不到确认。
        // 本地玩家皮肤由随后的 PlayerSkinPacket 分支补发。
        if (p instanceof StartGamePacket) {
            skinConfirmed = true;
        } else if (p instanceof PlayerSkinPacket ps && ps.getSkin() != null) {
            sendSkinCsp(ps.getUuid(), ps.getSkin(), immediate);
        } else if (p instanceof PlayerListPacket pl && pl.getAction() == PlayerListPacket.Action.ADD) {
            for (PlayerListPacket.Entry entry : pl.getEntries()) {
                if (entry.getSkin() != null) {
                    sendSkinCsp(entry.getUuid(), entry.getSkin(), immediate);
                }
            }
        }
    }

    private void sendSkinCsp(UUID uuid, SerializedSkin skin, boolean immediate) {
        if (uuid == null) return;
        try {
            BedrockServerSession session = real.getSession();
            BedrockCodec codec = session == null ? null : session.getCodec();
            // ConfirmSkin 可能被配置关闭（confirm-skin-enabled=false），此时 codec 没有该包定义，
            // 继续发送会在编码阶段抛异常并断线。
            if (codec == null || codec.getPacketDefinition(ConfirmSkinPacket.class) == null) return;
        } catch (Throwable ignored) {
            return;
        }

        byte[] image = null;
        String geo = null;
        try {
            if (skin.getSkinData() != null) {
                image = skin.getSkinData().getImage();
            }
            geo = skin.getGeometryData();
        } catch (Throwable ignored) {
            // 老版本 / 异常皮肤数据，按“无皮肤图”处理
        }

        ConfirmSkinPacket csp = new ConfirmSkinPacket();
        ConfirmSkinPacket.SkinEntry e = new ConfirmSkinPacket.SkinEntry();
        e.setUuid(uuid);
        e.setUidStr(String.valueOf(Math.abs(uuid.toString().replace("-", "").hashCode())));

        if (image != null && image.length > 0) {
            e.setValid(true);
            e.setSkinBytes(image);
            e.setGeoStr(geo != null ? geo : "");
            NeteaseExtension.debug("[netease] ConfirmSkin valid uuid=" + uuid
                + " image=" + image.length + " geo=" + (geo == null ? -1 : geo.length()));
        } else {
            // Persona / 4D 皮肤没有 64x64 皮肤图。ConfirmSkinSerializer 对 null 字段会抛异常
            // （writeByteArray / writeString 内部 checkNotNull），必须显式发 valid=false 的空条目，
            // 让对端回退到默认皮肤，而不是一直等待一个永远发不出去的确认包。
            e.setValid(false);
            e.setSkinBytes(new byte[0]);
            e.setGeoStr("");
            NeteaseExtension.debug("[netease] ConfirmSkin invalid(fallback) uuid=" + uuid);
        }

        csp.getEntries().add(e);
        if (immediate) real.sendPacketImmediately(csp); else real.sendPacket(csp);
    }

    private void rewriteStartGame(StartGamePacket sg) {
        sg.setBlockNetworkIdsHashed(true);
        sg.setBlockRegistryChecksum(0L);
        List<NbtMap> pal = sg.getBlockPalette();
        if (pal == null || pal.isEmpty()) return;
        TreeMap<Integer, NbtMap> sorted = new TreeMap<>();
        int idx = 0;
        for (NbtMap e : pal) {
            if (idx < hValid.length && hValid[idx]) sorted.put(rtToHash[idx], e);
            else if (idx < rtToHash.length) sorted.put(idx, e);
            idx++;
        }
        try {
            pal.clear();
            sorted.values().forEach(pal::add);
        } catch (UnsupportedOperationException immutablePalette) {
            // 某些 Geyser 版本会传只读 NbtList；哈希模式下顺序不影响解析，跳过排序即可。
            NeteaseExtension.debug("[netease] StartGame 调色板不可变，跳过哈希排序");
        }
    }

    private BlockDefinition wrapDef(BlockDefinition def) {
        if (def == null) return null;
        // 必须返回哈希注册表里的同一个实例：codec 的 checkDefinition 按同一性校验，
        // 每次 new 一个匿名 BlockDefinition 会直接抛 "Definition is not registered"。
        if (blockRegistry != null) return blockRegistry.wrap(def);
        return def;
    }

    private static final Unsafe U;
    static {
        try {
            Field f = Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            U = (Unsafe) f.get(null);
        } catch (Throwable e) { throw new ExceptionInInitializerError(e); }
    }

    /**
     * 事务性补丁：所有替换值先在临时对象里构建，全部成功后才写入新副本。
     * 任何必需字段缺失/类型不符都会抛异常，调用方使用未补丁副本或拒绝会话，
     * 绝不会留下“部分数组已哈希、部分仍连续”的半哈希方块表。
     */
    public static BlockMappings patchAll(BlockMappings source) throws Throwable {
        Map<NbtMap, GeyserBedrockBlock> canonical = new HashMap<>();

        // 必需字段：先构建，不修改 source。
        GeyserBedrockBlock[] javaToBedrock = buildArray(source, "javaToBedrockBlocks", canonical);
        GeyserBedrockBlock[] runtimeMap = buildArray(source, "bedrockRuntimeMap", canonical);
        GeyserBedrockBlock[] javaToVanilla = buildArray(source, "javaToVanillaBedrockBlocks", canonical);
        GeyserBedrockBlock air = buildSingletonRequired(source, "bedrockAir", canonical);
        Map<Object, Object> stateDefinitionMap = buildMapRequired(source, "stateDefinitionMap", canonical);

        // 可选字段：按当前 Geyser 版本能补则补，缺失不阻断必需补丁。
        Object water = buildSingletonOptional(source, "bedrockWater", canonical);
        Object movingBlock = buildSingletonOptional(source, "bedrockMovingBlock", canonical);
        Object commandBlock = buildSingletonOptional(source, "commandBlock", canonical);
        Object mobSpawnerBlock = buildSingletonOptional(source, "mobSpawnerBlock", canonical);
        Object netherPortalBlock = buildSingletonOptional(source, "netherPortalBlock", canonical);
        Map<Object, Object> itemFrames = buildMapOptional(source, "itemFrames", canonical);
        Map<Object, Object> structureBlockStates = buildMapOptional(source, "structureBlockStates", canonical);
        Set<Object> jigsawStates = buildSetOptional(source, "jigsawStates", canonical);
        Object2ObjectMap<Object, Object> customBlockStates = buildObject2ObjectMapOptional(
                source, "customBlockStateDefinitions", canonical);

        BlockMappings copy = cloneBlockMappings(source);
        put(copy, "javaToBedrockBlocks", javaToBedrock);
        put(copy, "bedrockRuntimeMap", runtimeMap);
        put(copy, "javaToVanillaBedrockBlocks", javaToVanilla);
        put(copy, "bedrockAir", air);
        put(copy, "stateDefinitionMap", stateDefinitionMap);
        putIfNotNull(copy, "bedrockWater", water);
        putIfNotNull(copy, "bedrockMovingBlock", movingBlock);
        putIfNotNull(copy, "commandBlock", commandBlock);
        putIfNotNull(copy, "mobSpawnerBlock", mobSpawnerBlock);
        putIfNotNull(copy, "netherPortalBlock", netherPortalBlock);
        putIfNotNull(copy, "itemFrames", itemFrames);
        putIfNotNull(copy, "structureBlockStates", structureBlockStates);
        putIfNotNull(copy, "jigsawStates", jigsawStates);
        putIfNotNull(copy, "customBlockStateDefinitions", customBlockStates);
        int fallbackCount = nc.geyserext.netease.util.NeteaseBlockIds.consumeFallbackCount();
        if (fallbackCount > 0 && NeteaseExtension.LOG != null) {
            NeteaseExtension.LOG.warning("[GeyserNetease] 网易调色板回退汇总: "
                    + fallbackCount + " 个方块状态无匹配，已回退旧哈希（开启 Debug 可查看明细）");
        }
        return copy;
    }

    private static GeyserBedrockBlock canonicalize(GeyserBedrockBlock block,
                                                   Map<NbtMap, GeyserBedrockBlock> canonical) {
        if (block == null || block.getState() == null) return block;
        return canonical.computeIfAbsent(block.getState(),
                state -> new GeyserBedrockBlock(nc.geyserext.netease.util.NeteaseBlockIds.networkId(state), state));
    }

    private static Object getField(BlockMappings source, String name) throws Throwable {
        Field field = BlockMappings.class.getDeclaredField(name);
        return U.getObject(source, U.objectFieldOffset(field));
    }

    private static void put(BlockMappings target, String name, Object value) throws Throwable {
        Field field = BlockMappings.class.getDeclaredField(name);
        U.putObject(target, U.objectFieldOffset(field), value);
    }

    private static void putIfNotNull(BlockMappings target, String name, Object value) throws Throwable {
        if (value != null) put(target, name, value);
    }

    private static GeyserBedrockBlock[] buildArray(BlockMappings source, String name,
                                                   Map<NbtMap, GeyserBedrockBlock> canonical) throws Throwable {
        Object value = getField(source, name);
        if (!(value instanceof GeyserBedrockBlock[] old)) {
            throw new IllegalStateException("BlockMappings." + name + " is missing or not an array");
        }
        GeyserBedrockBlock[] rep = new GeyserBedrockBlock[old.length];
        for (int i = 0; i < old.length; i++) {
            rep[i] = canonicalize(old[i], canonical);
        }
        return rep;
    }

    private static GeyserBedrockBlock buildSingletonRequired(BlockMappings source, String name,
                                                             Map<NbtMap, GeyserBedrockBlock> canonical) throws Throwable {
        Object old = getField(source, name);
        if (old instanceof GeyserBedrockBlock block && block.getState() != null) {
            return canonicalize(block, canonical);
        }
        throw new IllegalStateException("BlockMappings." + name + " is missing or not a block");
    }

    private static Object buildSingletonOptional(BlockMappings source, String name,
                                                 Map<NbtMap, GeyserBedrockBlock> canonical) {
        try {
            Object old = getField(source, name);
            return old instanceof GeyserBedrockBlock block && block.getState() != null
                    ? canonicalize(block, canonical) : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Map<Object, Object> buildMapRequired(BlockMappings source, String name,
                                                        Map<NbtMap, GeyserBedrockBlock> canonical) throws Throwable {
        Object value = getField(source, name);
        if (!(value instanceof Map old)) {
            throw new IllegalStateException("BlockMappings." + name + " is missing or not a map");
        }
        Map<Object, Object> rep = new HashMap<>(old.size());
        for (Map.Entry<?, ?> entry : ((Map<?, ?>) old).entrySet()) {
            Object v = entry.getValue();
            if (v instanceof GeyserBedrockBlock block) v = canonicalize(block, canonical);
            rep.put(entry.getKey(), v);
        }
        return rep;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Map<Object, Object> buildMapOptional(BlockMappings source, String name,
                                                        Map<NbtMap, GeyserBedrockBlock> canonical) {
        try {
            Object value = getField(source, name);
            if (!(value instanceof Map old)) return null;
            Map<Object, Object> rep = new HashMap<>(old.size());
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) old).entrySet()) {
                Object v = entry.getValue();
                if (v instanceof GeyserBedrockBlock block) v = canonicalize(block, canonical);
                rep.put(entry.getKey(), v);
            }
            return rep;
        } catch (Throwable ignored) {
            return null;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Set<Object> buildSetOptional(BlockMappings source, String name,
                                                Map<NbtMap, GeyserBedrockBlock> canonical) {
        try {
            Object value = getField(source, name);
            if (!(value instanceof Set old)) return null;
            Set<Object> rep = new HashSet<>(old.size());
            for (Object v : (Set<?>) old) {
                rep.add(v instanceof GeyserBedrockBlock block ? canonicalize(block, canonical) : v);
            }
            return rep;
        } catch (Throwable ignored) {
            return null;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Object2ObjectMap<Object, Object> buildObject2ObjectMapOptional(
            BlockMappings source, String name, Map<NbtMap, GeyserBedrockBlock> canonical) {
        try {
            Object value = getField(source, name);
            if (!(value instanceof Map old)) return null;
            Object2ObjectMap<Object, Object> rep = new Object2ObjectOpenHashMap<>(old.size());
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) old).entrySet()) {
                Object v = entry.getValue();
                if (v instanceof GeyserBedrockBlock block) v = canonicalize(block, canonical);
                rep.put(entry.getKey(), v);
            }
            return rep;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static BlockMappings cloneBlockMappings(BlockMappings orig) throws Throwable {
        BlockMappings copy = (BlockMappings) U.allocateInstance(BlockMappings.class);
        for (Field f : BlockMappings.class.getDeclaredFields()) {
            long off = U.objectFieldOffset(f);
            U.putObject(copy, off, U.getObject(orig, off));
        }
        for (String name : new String[]{"javaToBedrockBlocks", "bedrockRuntimeMap", "javaToVanillaBedrockBlocks"}) {
            Field f = BlockMappings.class.getDeclaredField(name);
            long off = U.objectFieldOffset(f);
            Object[] arr = (Object[]) U.getObject(orig, off);
            if (arr != null) U.putObject(copy, off, arr.clone());
        }
        return copy;
    }
}
