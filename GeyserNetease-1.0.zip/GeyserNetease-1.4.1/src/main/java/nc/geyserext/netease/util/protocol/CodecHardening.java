/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util.protocol;

import io.netty.buffer.ByteBuf;
import nc.geyserext.netease.NeteaseExtension;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.BedrockPacketSerializer;
import org.cloudburstmc.protocol.bedrock.packet.*;

import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 给网易 codec 套上 Geyser 的防护序列化器。
 *
 * <p>Geyser 在注册自己的 codec 时会调用 {@code CodecProcessor.processCodec}：把 EDU/弃用/未使用包标记为
 * “客户端发来即拒绝”，把若干服务端权威背包相关包改为“忽略”或“反序列化即抛异常”。
 * 本扩展自建 codec 时不会走这条路径，因此这里优先反射复用 Geyser 的实现（行为完全一致，含
 * {@code <975}、{@code <1001} 等版本分支）；反射不可用时退回到内置的最小防护集。</p>
 */
public final class CodecHardening {
    private static final AtomicBoolean WARNED = new AtomicBoolean();

    private CodecHardening() {
    }

    @SuppressWarnings("rawtypes")
    private static final BedrockPacketSerializer ILLEGAL_SERIALIZER = new BedrockPacketSerializer<>() {
        @Override
        public void serialize(ByteBuf buffer, BedrockCodecHelper helper, BedrockPacket packet) {
            throw new UnsupportedOperationException("Server tried to send unused packet "
                    + packet.getClass().getSimpleName());
        }

        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, BedrockPacket packet) {
            throw new UnsupportedOperationException("Client tried to send unused packet "
                    + packet.getClass().getSimpleName());
        }
    };

    @SuppressWarnings("rawtypes")
    private static final BedrockPacketSerializer IGNORED_SERIALIZER = new BedrockPacketSerializer<>() {
        @Override
        public void serialize(ByteBuf buffer, BedrockCodecHelper helper, BedrockPacket packet) {
        }

        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, BedrockPacket packet) {
        }
    };

    public static BedrockCodec apply(BedrockCodec codec) {
        try {
            Class<?> processor = Class.forName("org.geysermc.geyser.network.bedrock.CodecProcessor");
            Method method = processor.getDeclaredMethod("processCodec", BedrockCodec.class);
            method.setAccessible(true);
            BedrockCodec processed = (BedrockCodec) method.invoke(null, codec);
            if (processed != null) {
                return processed;
            }
        } catch (Throwable t) {
            if (WARNED.compareAndSet(false, true) && NeteaseExtension.LOG != null) {
                NeteaseExtension.LOG.warning("[netease] 复用 Geyser CodecProcessor 失败，改用内置最小防护: " + t);
            }
        }
        return applyFallback(codec);
    }

    /** 内置最小防护集：只覆盖不需要 Geyser 私有序列化器的部分，保证反射失败时仍有基本约束。 */
    @SuppressWarnings("unchecked")
    private static BedrockCodec applyFallback(BedrockCodec codec) {
        BedrockCodec.Builder builder = codec.toBuilder();
        for (Class<? extends BedrockPacket> type : new Class[]{
                PhotoTransferPacket.class, LabTablePacket.class, CodeBuilderSourcePacket.class,
                CreatePhotoPacket.class, NpcRequestPacket.class, PhotoInfoRequestPacket.class,
                ClientCheatAbilityPacket.class, CraftingEventPacket.class,
                ClientCacheBlobStatusPacket.class, SubClientLoginPacket.class,
                SubChunkRequestPacket.class, GameTestRequestPacket.class,
                DebugInfoPacket.class, EditorNetworkPacket.class, ScriptMessagePacket.class}) {
            builder.updateSerializer(type, (BedrockPacketSerializer) ILLEGAL_SERIALIZER);
        }
        for (Class<? extends BedrockPacket> type : new Class[]{
                ClientToServerHandshakePacket.class, EntityFallPacket.class,
                MapCreateLockedCopyPacket.class, MapInfoRequestPacket.class,
                SettingsCommandPacket.class, AnvilDamagePacket.class,
                ClientCacheStatusPacket.class, SimpleEventPacket.class,
                MultiplayerSettingsPacket.class, EmoteListPacket.class}) {
            builder.updateSerializer(type, (BedrockPacketSerializer) IGNORED_SERIALIZER);
        }
        return builder.build();
    }
}