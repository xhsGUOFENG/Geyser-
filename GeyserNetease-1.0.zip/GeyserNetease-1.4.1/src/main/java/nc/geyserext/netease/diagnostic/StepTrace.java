package nc.geyserext.netease.diagnostic;

import nc.geyserext.netease.NeteaseExtension;
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData;
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * 台阶/碰撞回弹诊断缓冲。
 *
 * <p>只在 packet-trace-v2 打开时记录；仅在 Y 上升或 onGround/vcol/hcol 变化时入队，
 * 最多保留 200 条，会话断开时一次性写入 logs/step-trace-时间.log。</p>
 */
public final class StepTrace {
    private static final int MAX_ENTRIES = 200;
    private static final double Y_EPSILON = 1.0E-4;
    /** 每个 StepTrace 实例独立的短 id，避免多个会话同一秒写入时互相覆盖。 */
    private final String instanceId = UUID.randomUUID().toString().substring(0, 8);

    private final Deque<Entry> entries = new ArrayDeque<>(MAX_ENTRIES);
    private boolean hasState;
    private double lastY;
    private boolean lastOnGround;
    private boolean lastVerticalCollision;
    private boolean lastHorizontalCollision;
    private boolean lastFlying;

    public synchronized void record(PlayerAuthInputPacket packet, Boolean onGround,
                                    boolean flying, String gameMode) {
        if (!NeteaseExtension.packetTrace()) return;

        double y = packet.getPosition().getY();
        double dy = packet.getDelta().getY();
        boolean vertical = packet.getInputData().contains(PlayerAuthInputData.VERTICAL_COLLISION);
        boolean horizontal = packet.getInputData().contains(PlayerAuthInputData.HORIZONTAL_COLLISION);
        boolean ground = Boolean.TRUE.equals(onGround);

        // 创造飞行时 Y 会持续上升，不能把这种上升当成台阶/碰撞记录。
        boolean rising = hasState && !flying && y > lastY + Y_EPSILON;
        boolean flagsChanged = hasState
                && (ground != lastOnGround || vertical != lastVerticalCollision
                || horizontal != lastHorizontalCollision || flying != lastFlying);

        if (rising || flagsChanged) {
            entries.addLast(new Entry(packet.getTick(), y, dy, ground, vertical, horizontal,
                    flying, gameMode, packet.getInputMode() == null ? "?" : packet.getInputMode().name(), false));
            while (entries.size() > MAX_ENTRIES) entries.removeFirst();
        }

        hasState = true;
        lastY = y;
        lastOnGround = ground;
        lastVerticalCollision = vertical;
        lastHorizontalCollision = horizontal;
        lastFlying = flying;
    }

    /** 收到 Java ClientboundPlayerPositionPacket 时，把最近一条 step 标记为服务端校正。 */
    public synchronized void markServerCorrection() {
        Entry last = entries.peekLast();
        if (last != null) {
            last.serverCorrection = true;
        }
    }

    public synchronized void flush() {
        if (entries.isEmpty()) return;
        Path dir = Path.of("logs");
        String file = "step-trace-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))
                + "-" + instanceId + ".log";
        Path out = dir.resolve(file);
        List<String> lines = new ArrayList<>(entries.size() + 1);
        lines.add("# tick y dy onGround vcol hcol flying gameMode mode serverCorrection");
        for (Entry e : entries) {
            lines.add(String.format(Locale.ROOT,
                    "[step-trace] tick=%d y=%.3f dy=%.4f onGround=%s vcol=%s hcol=%s flying=%s gameMode=%s mode=%s serverCorrection=%s",
                    e.tick, e.y, e.dy, e.onGround, e.vertical, e.horizontal,
                    e.flying, e.gameMode, e.mode, e.serverCorrection));
        }
        try {
            Files.createDirectories(dir);
            Files.write(out, lines, StandardCharsets.UTF_8);
            if (NeteaseExtension.LOG != null) {
                NeteaseExtension.LOG.info("[step-trace] 已写入 " + out.toAbsolutePath() + "（" + entries.size() + " 条）");
            }
        } catch (IOException e) {
            if (NeteaseExtension.LOG != null) {
                NeteaseExtension.LOG.warning("[step-trace] 写入失败: " + e.getMessage());
            }
        }
        entries.clear();
    }

    private static final class Entry {
        final long tick;
        final double y;
        final double dy;
        final boolean onGround;
        final boolean vertical;
        final boolean horizontal;
        final boolean flying;
        final String gameMode;
        final String mode;
        boolean serverCorrection;

        Entry(long tick, double y, double dy, boolean onGround, boolean vertical,
              boolean horizontal, boolean flying, String gameMode,
              String mode, boolean serverCorrection) {
            this.tick = tick;
            this.y = y;
            this.dy = dy;
            this.onGround = onGround;
            this.vertical = vertical;
            this.horizontal = horizontal;
            this.flying = flying;
            this.gameMode = gameMode;
            this.mode = mode;
            this.serverCorrection = serverCorrection;
        }
    }
}
