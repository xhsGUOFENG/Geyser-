/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util.protocol;

import nc.geyserext.netease.NeteaseExtension;
import nc.geyserext.netease.config.CompatSettings;
import org.cloudburstmc.protocol.bedrock.codec.*;
import org.cloudburstmc.protocol.bedrock.codec.v630_netease.Bedrock_v630_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v686_netease.Bedrock_v686_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v766_netease.Bedrock_v766_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v819_netease.Bedrock_v819_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v860_netease.Bedrock_v860_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v898_netease.Bedrock_v898_NetEase;
import org.cloudburstmc.protocol.bedrock.data.EncodingSettings;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class NeteaseCodecRegistry {

    private static final Map<Integer, BedrockCodec> CODECS = new ConcurrentHashMap<>();
    private static volatile CompatSettings settings = CompatSettings.defaults();

    static {
        rebuild(CompatSettings.from(NeteaseExtension.CONFIG));
    }

    /**
     * 按当前配置重建全部网易 codec。
     *
     * <p>配置只在启动时读取一次，运行期不重建，避免已建立会话的 codec 与 helper 状态不一致。
     * 扩展初始化时会主动调用一次，确保首个连接到来前 codec 已经就绪。</p>
     */
    public static synchronized void rebuild(CompatSettings newSettings) {
        settings = newSettings == null ? CompatSettings.defaults() : newSettings;

        Map<Integer, BedrockCodec> next = new LinkedHashMap<>();
        for (BedrockCodec base : List.of(
                Bedrock_v630_NetEase.CODEC,
                Bedrock_v686_NetEase.CODEC,
                Bedrock_v766_NetEase.CODEC,
                Bedrock_v819_NetEase.createCodec(settings),
                Bedrock_v860_NetEase.createCodec(settings),
                Bedrock_v898_NetEase.createCodec(settings))) {
            next.put(base.getProtocolVersion(), withPerConnectionHelper(CodecHardening.apply(base)));
        }
        CODECS.clear();
        CODECS.putAll(next);

        if (NeteaseExtension.LOG != null) {
            NeteaseExtension.LOG.info("[netease] 已注册 codec: " + next.keySet()
                    + "（898 线格式=" + (settings.legacyWireFormat() ? "v860" : "v898")
                    + "，PlayerAuthInput 位图=" + settings.authInputBitmap() + "）");
        }
    }

    /**
     * 给每个连接发一份新的 helper。
     *
     * <p>早先的实现把同一个 helper 实例通过 {@code helper(() -> h)} 交给所有连接，
     * 而 Geyser 会在 startGame 时按会话写入 itemDefinitions / blockDefinitions，
     * 多玩家并发时这些字段会被互相覆盖。这里改成每次调用 supplier 都新建并配置。</p>
     */
    private static BedrockCodec withPerConnectionHelper(BedrockCodec codec) {
        return codec.toBuilder().helper(() -> {
            BedrockCodecHelper helper = codec.createHelper();
            helper.setEncodingSettings(ENCODING_SETTINGS);
            return helper;
        }).build();
    }

    /**
     * 解码上限。
     *
     * <p>这里曾经全部设为 {@link Integer#MAX_VALUE}，等于把 bedrock-codec 内置的畸形包防护
     * 整体关掉：客户端只要在包里声明一个超大长度（例如 BiomeDefinitionList 的 tag 数量），
     * 就能让服务端按该长度预分配内存，直接 OutOfMemoryError 杀掉整个 JVM。
     * 现在改用与上游 Geyser/bedrock-codec 一致的上限，既保留防护，又足够容纳正常网易包
     * （皮肤贴图 &lt; 1MB、geo JSON &lt; 32KB、列表条目远小于 1536）。</p>
     */
    private static final EncodingSettings ENCODING_SETTINGS = EncodingSettings.builder()
            .maxListSize(1536)
            .maxByteArraySize(1024 * 1024)
            .maxNetworkNBTSize(512 * 1024 * 1024)
            .maxItemNBTSize(100 * 1024)
            .maxStringLength(32 * 1024)
            .build();

    public static BedrockCodec getCodec(int version) { return CODECS.get(version); }

    /** 当前已注册的网易协议版本，供注册表别名使用。 */
    public static Set<Integer> versions() { return Set.copyOf(CODECS.keySet()); }

    public static CompatSettings settings() { return settings; }
}