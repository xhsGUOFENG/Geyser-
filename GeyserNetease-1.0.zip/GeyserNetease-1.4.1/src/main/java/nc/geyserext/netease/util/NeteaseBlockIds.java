/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util;

import org.cloudburstmc.nbt.NbtMap;
import org.cloudburstmc.nbt.NbtType;
import org.cloudburstmc.nbt.NbtUtils;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 网易 1.21.130 客户端实际使用的是 1.21.120 方块调色板（15830 个状态），
 * 而 Geyser 2.12.1 内置的是 26.60 调色板（23960 个状态）。两者并不等价：
 * 例如 26.60 的楼梯有 40 个状态并带 {@code minecraft:corner}，网易只有 8 个状态；
 * 栅栏/玻璃板/墙也新增了连接状态。直接对 26.60 状态做 FNV 哈希会得到客户端不认识的 ID。
 *
 * <p>这里加载网易调色板的原始 {@code network_id}：对 Geyser 状态按“同名 + 网易状态键
 * 全部匹配”查找，忽略 Geyser 多出来的新状态键。这样楼梯角、栅栏连接等差异会落到网易
 * 客户端真实存在的同基础状态上，客户端才能正确显示和计算碰撞。</p>
 */
public final class NeteaseBlockIds {

    private static final Map<String, List<Entry>> BY_NAME = new HashMap<>();
    private static final Set<String> WARNED = ConcurrentHashMap.newKeySet();
    /** 每个方块名只计一次；登录结束时由 patchAll 汇总成一条日志。 */
    private static final AtomicInteger FALLBACK_COUNT = new AtomicInteger();

    /**
     * 网易 1.21.120 调色板给工作台/熔炉新增了 custom_appearance=0。
     * 该状态在网易客户端有碰撞但没有可渲染模型，直接使用会表现为“完全透明但挡人”；
     * 回退到无 custom_appearance 的 26.60 原版状态，客户端会使用正常方块模型。
     */
    private static final Set<String> CUSTOM_APPEARANCE_BLOCKS = Set.of(
            "minecraft:crafting_table", "minecraft:furnace", "minecraft:lit_furnace");

    static {
        load();
    }

    private NeteaseBlockIds() {
    }

    public static int networkId(NbtMap state) {
        if (state == null) {
            return -2;
        }
        String name = state.getString("name", "");
        NbtMap states = state.getCompound("states");
        if (states == null) {
            states = NbtMap.EMPTY;
        }

        if (CUSTOM_APPEARANCE_BLOCKS.contains(name) && !states.containsKey("custom_appearance")) {
            int legacy = BlockHashUtils.fnv1a32Nbt(state);
            if (WARNED.add(name + ":legacy")) {
                FALLBACK_COUNT.incrementAndGet();
                debug("[GeyserNetease] " + name + " 使用无 custom_appearance 的原版状态 ID " + legacy
                        + "（custom_appearance 状态在网易客户端无模型）");
            }
            return legacy;
        }

        List<Entry> entries = BY_NAME.get(name);
        if (entries != null) {
            Entry best = null;
            for (Entry entry : entries) {
                if (!matches(entry.states, states)) {
                    continue;
                }
                if (best == null
                        || entry.states.size() > best.states.size()
                        || (entry.states.size() == best.states.size() && entry.states.equals(states))) {
                    best = entry;
                }
            }
            if (best != null) {
                return best.networkId;
            }
        }
        // 不再静默：每个方块名只告警一次。保留旧哈希只是为了维持既有行为，
        // 真正缺失的方块在网易客户端本来就没有对应状态，无法凭空生成正确 ID。
        int fallback = BlockHashUtils.fnv1a32Nbt(state);
        if (WARNED.add(name.isEmpty() ? "<unknown>" : name)) {
            FALLBACK_COUNT.incrementAndGet();
            debug("[GeyserNetease] 网易调色板无匹配状态: " + name
                    + " states=" + states + "，暂回退旧哈希 " + fallback);
        }
        return fallback;
    }

    private static boolean matches(NbtMap expected, NbtMap actual) {
        for (Map.Entry<String, Object> entry : expected.entrySet()) {
            String key = entry.getKey();
            Object expectedValue = entry.getValue();
            Object actualValue = actual.get(key);
            if (actualValue == null && "custom_appearance".equals(key)) {
                // 网易工作台/熔炉在 1.21.120 调色板新增了 custom_appearance，
                // Geyser 26.60 状态没有该键，按网易默认值 0 处理。
                actualValue = zeroLike(expectedValue);
            }
            if (!Objects.equals(actualValue, expectedValue)) {
                return false;
            }
        }
        return true;
    }

    private static Object zeroLike(Object value) {
        if (value instanceof Byte) return (byte) 0;
        if (value instanceof Short) return (short) 0;
        if (value instanceof Integer) return 0;
        if (value instanceof Long) return 0L;
        return null;
    }

    public static int consumeFallbackCount() {
        return FALLBACK_COUNT.getAndSet(0);
    }

    private static void debug(String message) {
        try {
            nc.geyserext.netease.NeteaseExtension.debug(message);
        } catch (Throwable ignored) {
            // 日志不可用不能影响方块 ID 计算。
        }
    }

    private static void warn(String message) {
        try {
            if (nc.geyserext.netease.NeteaseExtension.LOG != null) {
                nc.geyserext.netease.NeteaseExtension.LOG.warning(message);
            } else {
                System.err.println(message);
            }
        } catch (Throwable ignored) {
            // 日志不可用不能影响方块 ID 计算。
        }
    }

    @SuppressWarnings("unchecked")
    private static void load() {
        try (InputStream in = NeteaseBlockIds.class.getResourceAsStream("/netease/block_palette.1_21_120.nbt")) {
            if (in == null) {
                return;
            }
            NbtMap root = (NbtMap) NbtUtils.createGZIPReader(in).readTag();
            List<NbtMap> blocks = (List<NbtMap>) root.getList("blocks", NbtType.COMPOUND);
            for (NbtMap block : blocks) {
                String name = block.getString("name", "");
                if (name.isEmpty()) {
                    continue;
                }
                NbtMap states = block.getCompound("states");
                if (states == null) {
                    states = NbtMap.EMPTY;
                }
                int networkId = block.getInt("network_id", Integer.MIN_VALUE);
                if (networkId == Integer.MIN_VALUE) {
                    continue;
                }
                BY_NAME.computeIfAbsent(name, key -> new ArrayList<>())
                        .add(new Entry(states, networkId));
            }
        } catch (Throwable t) {
            warn("[GeyserNetease] 网易方块调色板加载失败，方块 ID 将回退旧哈希: " + t);
        }
    }

    private record Entry(NbtMap states, int networkId) {
    }
}
