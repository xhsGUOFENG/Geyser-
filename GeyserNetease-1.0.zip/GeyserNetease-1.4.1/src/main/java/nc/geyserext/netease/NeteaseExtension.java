/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease;

import nc.geyserext.netease.config.*;
import nc.geyserext.netease.util.*;
import nc.geyserext.netease.util.protocol.NeteaseCodecRegistry;
import org.geysermc.event.subscribe.Subscribe;
import org.geysermc.geyser.api.event.lifecycle.GeyserPostInitializeEvent;
import org.geysermc.geyser.api.event.lifecycle.GeyserPostReloadEvent;
import org.geysermc.geyser.api.extension.*;

public class NeteaseExtension implements Extension {

    /** 构建标识：用于在服务器日志中确认运行的是哪个版本。 */
    public static final String BUILD_TAG = "geyser2.12.1-20261113+v898fix36logspam";

    /** 诊断日志开关：-DGeyserNetease.Debug=true 打开（默认关闭）。 */
    public static final boolean DEBUG =
        Boolean.parseBoolean(System.getProperty("GeyserNetease.Debug", "false"));

    public static ExtensionLogger LOG;
    public static NeteaseConfig CONFIG;

    /** 本地诊断日志：系统属性或 debug-mode 打开时输出；不上传。 */
    public static void debug(String message) {
        if (debugEnabled() && LOG != null) LOG.info(message);
    }

    /** debug 是否生效：系统属性 -DGeyserNetease.Debug=true 或配置文件 debug-mode: true。 */
    public static boolean debugEnabled() {
        return DEBUG || (CONFIG != null && CONFIG.debugMode());
    }

    /** 攻击键排障开关：系统属性或 config.yml 的 packet-trace-v3；只写本地日志。 */
    public static boolean packetTrace() {
        return Boolean.parseBoolean(System.getProperty("GeyserNetease.PacketTrace", "false"))
                || (CONFIG != null && CONFIG.packetTrace());
    }

    /** 实际加载的扩展 jar 路径，用于排除扩展目录里多个版本共存。 */
    public static String jarLocation() {
        try {
            var source = NeteaseExtension.class.getProtectionDomain().getCodeSource();
            return source == null || source.getLocation() == null ? "unknown" : source.getLocation().toString();
        } catch (Throwable t) {
            return "unknown";
        }
    }

    @Subscribe
    public void onPostInit(GeyserPostInitializeEvent event) {
        LOG = logger();
        if (DEBUG) LOG.info("NetEase Extension build: " + BUILD_TAG);
        LOG.info("NetEase Extension starting...");

        CONFIG = NeteaseConfigLoader.load(this, NeteaseExtension.class);
        CompatSettings settings = CompatSettings.from(CONFIG);
        LOG.info("NetEase Extension build=" + BUILD_TAG + ", jar=" + jarLocation());
        LOG.info("NetEase 898 settings: wire=" + (settings.legacyWireFormat() ? "v860" : "v898")
                + ", animate=" + settings.animateFormat898() + ", packet-trace-v3=" + packetTrace()
                + ", attack-cooldown(legacy)=" + (CONFIG != null && CONFIG.attackCooldown())
                + ", bossbar-cooldown=" + (CONFIG != null && CONFIG.bossBarCooldown()));

        try {
            NeteaseCodecRegistry.rebuild(settings);
            nc.geyserext.netease.util.protocol.RegistryCompat.installAliases(NeteaseCodecRegistry.versions());
        } catch (Throwable e) {
            LOG.error("Codec registry init failed", e);
        }

        try {
            ServerRestartUtil.restart(CONFIG != null && CONFIG.onlyNeteaseClients());
            LOG.info("NetEase Extension initialized — RakNet v8 clients supported.");
        } catch (Exception e) { LOG.error("Init failed", e); }

    }

    /**
     * Geyser 重载会重建 RaknetServer 并恢复标准初始化器；这里重新装回网易监听器，
     * 否则 /geyser reload 之后网易玩家会全部进不来。
     */
    @Subscribe
    public void onPostReload(GeyserPostReloadEvent event) {
        LOG = logger();
        CONFIG = NeteaseConfigLoader.load(this, NeteaseExtension.class);
        CompatSettings settings = CompatSettings.from(CONFIG);
        LOG.info("NetEase Extension reloaded build=" + BUILD_TAG + ", jar=" + jarLocation()
                + ", animate=" + settings.animateFormat898() + ", packet-trace-v3=" + packetTrace()
                + ", attack-cooldown(legacy)=" + (CONFIG != null && CONFIG.attackCooldown())
                + ", bossbar-cooldown=" + (CONFIG != null && CONFIG.bossBarCooldown()));
        try {
            NeteaseCodecRegistry.rebuild(settings);
            nc.geyserext.netease.util.protocol.RegistryCompat.installAliases(NeteaseCodecRegistry.versions());
        } catch (Throwable e) {
            LOG.error("Codec registry reload failed", e);
        }
        try {
            ServerRestartUtil.restart(CONFIG != null && CONFIG.onlyNeteaseClients());
            LOG.info("NetEase listener reinstalled after Geyser reload.");
        } catch (Exception e) {
            LOG.error("NetEase listener reinstall failed after reload", e);
        }
    }
}
