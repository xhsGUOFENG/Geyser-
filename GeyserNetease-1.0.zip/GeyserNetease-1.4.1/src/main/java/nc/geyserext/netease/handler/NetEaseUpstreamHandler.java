/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.handler;

import nc.geyserext.netease.NeteaseExtension;
import nc.geyserext.netease.session.NeteaseSession;
import nc.geyserext.netease.util.protocol.NeteaseCodecRegistry;
import org.cloudburstmc.math.vector.Vector2f;
import org.cloudburstmc.math.vector.Vector3f;
import org.cloudburstmc.math.vector.Vector3i;
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.data.PacketCompressionAlgorithm;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes;
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData;
import org.cloudburstmc.protocol.bedrock.data.SoundEvent;
import org.cloudburstmc.protocol.bedrock.data.auth.CertificateChainPayload;
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryActionData;
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventorySource;
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType;
import org.cloudburstmc.protocol.bedrock.netty.codec.compression.*;
import org.cloudburstmc.protocol.bedrock.packet.*;
import org.cloudburstmc.protocol.bedrock.util.*;
import org.cloudburstmc.protocol.common.PacketSignal;
import org.geysermc.geyser.GeyserImpl;
import org.geysermc.geyser.api.event.bedrock.SessionInitializeEvent;
import org.geysermc.geyser.event.type.SessionLoadResourcePacksEventImpl;
import org.geysermc.geyser.network.bedrock.GameProtocol;
import org.geysermc.geyser.registry.BlockRegistries;
import org.geysermc.geyser.registry.Registries;
import org.geysermc.geyser.session.GeyserSession;
import org.geysermc.geyser.api.network.AuthType;
import org.geysermc.geyser.session.auth.*;
import org.geysermc.geyser.text.GeyserLocale;
import org.geysermc.mcprotocollib.protocol.data.game.entity.object.Direction;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.GameMode;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.PlayerAction;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.player.ServerboundPlayerActionPacket;

import javax.crypto.SecretKey;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.security.KeyPair;
import java.security.PublicKey;
import java.util.*;

public class NetEaseUpstreamHandler extends UpstreamHandlerBase {

    private final nc.geyserext.netease.diagnostic.StepTrace stepTrace =
            new nc.geyserext.netease.diagnostic.StepTrace();
    private boolean stepSnifferAttached;

    /**
     * 是否跳过 Bedrock 层加密握手。
     *
     * <p>网易客户端通过 NetherNet（WebRTC/SCTP，本身已由 DTLS 加密）连接，
     * 实测它收到 {@code ServerToClientHandshake} 后会静默忽略并最终超时
     * （4 种批次封装格式均如此），即局域网流程不做 Bedrock 层加密。
     * 因此默认跳过加密握手，直接进入资源包阶段。</p>
     *
     * <p>可用 {@code -DGeyserNetease.SkipEncryption=false} 关闭。</p>
     */
    private static final boolean SKIP_ENCRYPTION =
        !"false".equalsIgnoreCase(System.getProperty("GeyserNetease.SkipEncryption", "true"));

    private NeteaseSession neteaseSession;

    /** 网易扩展明确支持的协议版本；其它版本在登录前直接断开。 */
    private static final Set<Integer> SUPPORTED_NETEASE_VERSIONS = Set.of(819, 860, 898);

    /** 网易会话专用 BossBar 的隐藏实体 ID；首次触发时生成。 */
    private long bossBarEntityId;

    /** BossBar 动画代际号；新一次攻击会取消旧任务，避免多个任务叠加。 */
    private long bossBarGeneration;

    /** BossBar 当前是否已经 CREATE，结束或断线时需要 REMOVE。 */
    private boolean bossBarVisible;

    /** 三路攻击触发可能在几毫秒内同时到达，用短窗口避免同一次点击反复重置 BossBar。 */
    private long lastBossBarStartMs;

    /** 是否已经下发过 PlayStatus / ResourcePacksInfo，避免重复发送。 */
    private boolean loginFlowCompleted;

    public NetEaseUpstreamHandler(GeyserImpl geyser, GeyserSession session) {
        super(geyser, session);
    }

    @Override
    public PacketSignal handle(RequestNetworkSettingsPacket packet) {
        Integer rakVer = getRakVersion();
        boolean isNetEase = rakVer != null && rakVer == 8;
        if (!isNetEase) {
            NeteaseExtension.debug("[GeyserNetease] 非网易连接（rakVer=" + rakVer + "），交回标准处理");
            return super.handle(packet);
        }

        int protocolVersion = packet.getProtocolVersion();
        if (!SUPPORTED_NETEASE_VERSIONS.contains(protocolVersion)) {
            NeteaseExtension.debug("[GeyserNetease] 不支持的网易协议版本 " + protocolVersion + "，断开连接");
            session.disconnect("您的网易Minecraft版本不受支持");
            return PacketSignal.HANDLED;
        }

        BedrockCodec codec = NeteaseCodecRegistry.getCodec(protocolVersion);
        if (codec == null) {
            // 正常情况下白名单版本都已注册；保留兜底，避免配置损坏时进入半初始化状态。
            NeteaseExtension.debug("[GeyserNetease] 白名单版本缺少 codec " + protocolVersion + "，断开连接");
            session.disconnect("您的网易Minecraft版本不受支持");
            return PacketSignal.HANDLED;
        }
        NeteaseExtension.debug("[GeyserNetease] 网易路径已激活：rakVer=" + rakVer
            + " 协议=" + protocolVersion + " 跳过加密=" + SKIP_ENCRYPTION);

        session.getUpstream().getSession().setCodec(codec);
        neteaseSession = new NeteaseSession(session, protocolVersion, codec);

        NetworkSettingsPacket resp = new NetworkSettingsPacket();
        resp.setCompressionAlgorithm(PacketCompressionAlgorithm.ZLIB);
        resp.setCompressionThreshold(512);
        session.sendUpstreamPacketImmediately(resp);

        NetEaseCompression nc = new NetEaseCompression();
        nc.setLevel(geyser.config().advanced().bedrock().compressionLevel());
        session.getUpstream().getSession().getPeer().setCompression(new SimpleCompressionStrategy(nc));

        networkSettingsRequested = true;
        return PacketSignal.HANDLED;
    }

    @Override
    public PacketSignal handle(LoginPacket packet) {
        if (neteaseSession == null) return super.handle(packet);
        if (!networkSettingsRequested) { session.disconnect("Protocol error"); return PacketSignal.HANDLED; }
        int loginProtocol = packet.getProtocolVersion();
        if (!SUPPORTED_NETEASE_VERSIONS.contains(loginProtocol)
                || loginProtocol != neteaseSession.protocolVersion()) {
            NeteaseExtension.debug("[GeyserNetease] LoginPacket 协议版本异常: request="
                    + neteaseSession.protocolVersion() + " login=" + loginProtocol);
            session.disconnect("您的网易Minecraft版本不受支持");
            return PacketSignal.HANDLED;
        }
        if (receivedLoginPacket) { session.disconnect("Duplicate login"); session.forciblyCloseUpstream(); return PacketSignal.HANDLED; }
        receivedLoginPacket = true;

        if (!(packet.getAuthPayload() instanceof CertificateChainPayload)) {
            NeteaseExtension.debug("[GeyserNetease] LoginPacket 缺少证书链，拒绝登录");
            session.disconnect("登录数据无效");
            return PacketSignal.HANDLED;
        }

        try {
            if (packet.getAuthPayload() instanceof CertificateChainPayload chain) {
                ChainValidationResult result = NetEaseEncryptionUtils.validateChain(chain);
                var extra = result.identityClaims().extraData;
                String name = extra.displayName != null ? extra.displayName : "NetEasePlayer";
                Long iat = (Long) result.rawIdentityClaims().get("iat");

                long neteaseUid = 0;
                Object red = result.rawIdentityClaims().get("extraData");
                if (red instanceof Map) {
                    Object u = ((Map<?, ?>) red).get("uid");
                    if (u instanceof Number) neteaseUid = ((Number) u).longValue();
                }
                if (neteaseUid == 0) neteaseUid = Math.abs(name.hashCode());
                neteaseSession.setUid(neteaseUid);

                String rawId = extra.identity != null ? extra.identity.toString() : null;
                UUID javaUuid = toStableUUID(rawId, neteaseUid);

                String xuid = String.valueOf(neteaseUid);

                session.setAuthData(new AuthData(name, javaUuid, xuid, iat != null ? iat : -1, extra.minecraftId != null ? extra.minecraftId : ""));
                session.setCertChainData(chain.getChain());

                if (packet.getClientJwt() != null && !packet.getClientJwt().isEmpty()) {
                    try {
                        byte[] cd = EncryptionUtils.verifyClientData(packet.getClientJwt(), result.identityClaims().parsedIdentityPublicKey());
                        if (cd != null) { BedrockClientData bcd = GeyserImpl.GSON.fromJson(new String(cd), BedrockClientData.class); bcd.setOriginalString(packet.getClientJwt()); session.setClientData(bcd); }
                    } catch (Exception ignored) {}
                }
                if (session.getClientData() == null)
                    session.setClientData(buildFakeClientData(name, sessionGameVersion()));
                patchServerAddress(session.getClientData(), serverAddress(geyser));

                if (!SKIP_ENCRYPTION) {
                    NeteaseExtension.debug("[GeyserNetease] 发送 ServerToClientHandshake（加密握手）");
                    startEncryptionHandshake(session, result.identityClaims().parsedIdentityPublicKey());
                    if (session.isClosed()) { session.forciblyCloseUpstream(); return PacketSignal.HANDLED; }
                    neteaseSession.setLoginDeferred(true);
                } else {
                    // 网易局域网流程不做 Bedrock 层加密：不发送握手、不启用加密
                    NeteaseExtension.debug("[GeyserNetease] 已跳过 ServerToClientHandshake（网易局域网流程不做 Bedrock 层加密）");
                    neteaseSession.setLoginDeferred(false);
                }
            }
        } catch (Exception e) { session.disconnect("disconnectionScreen.internalError.cantConnect"); NeteaseExtension.LOG.error("NetEase auth failed", e); return PacketSignal.HANDLED; }

        // 按客户端实际上报的协议版本选择映射；RegistryCompat 只在缺失档位时补充默认别名。
        int spoofedVersion = neteaseSession.protocolVersion();
        var shared = BlockRegistries.BLOCKS.forVersion(spoofedVersion);
        org.geysermc.geyser.registry.type.BlockMappings blockMappings;
        try {
            // 必须使用独立副本；克隆失败时绝不能退回 shared 再打补丁，否则会污染全服方块表。
            blockMappings = nc.geyserext.netease.session.SpoofedUpstream.cloneBlockMappings(shared);
        } catch (Throwable e) {
            NeteaseExtension.LOG.error("BlockMappings clone failed; rejecting NetEase session", e);
            session.disconnect("disconnectionScreen.internalError.cantConnect");
            return PacketSignal.HANDLED;
        }

        boolean patched = false;
        try {
            // patchAll 返回新副本；失败时保留未补丁副本，不会留下半哈希表。
            blockMappings = nc.geyserext.netease.session.SpoofedUpstream.patchAll(blockMappings);
            patched = true;
        } catch (Throwable e) {
            NeteaseExtension.LOG.error("BlockMappings patch failed; continuing with unpatched session copy", e);
        }
        session.setBlockMappings(blockMappings);
        session.setItemMappings(Registries.ITEMS.forVersion(spoofedVersion));

        int maxId = 0;
        for (int i = 0; blockMappings.getDefinition(i) != null; i++) maxId = i;
        int[] rtToHash = new int[maxId + 1];
        boolean[] hValid = new boolean[maxId + 1];
        try {
            for (int i = 0; i <= maxId; i++) {
                var block = blockMappings.getDefinition(i);
                if (block instanceof org.geysermc.geyser.registry.type.GeyserBedrockBlock gb && gb.getState() != null) {
                    rtToHash[i] = nc.geyserext.netease.util.NeteaseBlockIds.networkId(gb.getState());
                    hValid[i] = true;
                }
            }
        } catch (Throwable t) {
            // 单个方块定义异常不应影响整局游戏，保留已构建的部分哈希表。
            NeteaseExtension.LOG.error("Block hash table build failed", t);
        }

        try {
            var spoofed = new nc.geyserext.netease.session.SpoofedUpstream(
                session.getUpstream(), session.getUpstream().getSession(), rtToHash, hValid, patched, neteaseSession.uid());
            if (patched) {
                var registry = new nc.geyserext.netease.util.NeteaseBlockRegistry(blockMappings);
                spoofed.setBlockRegistry(registry);
                session.getUpstream().getCodecHelper().setBlockDefinitions(registry);
                // 物品表里的方块定义仍是连续运行时 ID；必须同步替换成同一批哈希实例，
                // 否则客户端拿到的手持方块无法映射到 hashed 调色板，放置会被本地预测成幽灵方块。
                session.setItemMappings(nc.geyserext.netease.util.NeteaseItemMappings.rewrite(
                        session.getItemMappings(), registry));
            }
            java.lang.reflect.Field upF = org.geysermc.geyser.session.GeyserSession.class.getDeclaredField("upstream");
            upF.setAccessible(true); upF.set(session, spoofed);
        } catch (Exception e) { NeteaseExtension.LOG.error("SpoofedUpstream inject failed: " + e.getMessage()); }

        geyser.getSessionManager().addPendingSession(session);
        geyser.eventBus().fire(new SessionInitializeEvent(session));
        this.resourcePackLoadEvent = new SessionLoadResourcePacksEventImpl(session);
        this.geyser.eventBus().fireEventElseKick(this.resourcePackLoadEvent, session);
        if (session.isClosed()) return PacketSignal.HANDLED;
        session.integratedPackActive(resourcePackLoadEvent.isIntegratedPackActive());
        GeyserLocale.loadGeyserLocale(session.locale());

        if (SKIP_ENCRYPTION && !loginFlowCompleted) {
            // 没有加密握手，客户端不会发 ClientToServerHandshake，
            // 因此这里直接下发 PlayStatus + ResourcePacksInfo
            sendLoginSuccessAndPacks();
        }
        return PacketSignal.HANDLED;
    }

    /** 发送 PlayStatus(LOGIN_SUCCESS) 与 ResourcePacksInfo，进入资源包阶段。 */
    private void sendLoginSuccessAndPacks() {
        if (loginFlowCompleted || session.isClosed()) return;
        loginFlowCompleted = true;
        NeteaseExtension.debug("[GeyserNetease] 下发 PlayStatus(LOGIN_SUCCESS) + ResourcePacksInfo");

        PlayStatusPacket ps = new PlayStatusPacket();
        ps.setStatus(PlayStatusPacket.Status.LOGIN_SUCCESS);
        session.sendUpstreamPacket(ps);
        if (session.isClosed()) return;

        ResourcePacksInfoPacket rpi = new ResourcePacksInfoPacket();
        rpi.getResourcePackInfos().addAll(this.resourcePackLoadEvent.infoPacketEntries());
        rpi.setVibrantVisualsForceDisabled(!session.isAllowVibrantVisuals());
        rpi.setForcedToAccept(geyser.config().gameplay().forceResourcePacks() || resourcePackLoadEvent.isIntegratedPackActive());
        rpi.setWorldTemplateId(java.util.UUID.randomUUID()); rpi.setWorldTemplateVersion("*");
        session.sendUpstreamPacket(rpi);
    }

    @Override
    public PacketSignal handle(PlayerAuthInputPacket packet) {
        // 网易把 onGround 单独放在包尾，而 Geyser 2.12.1 的 BedrockMovePlayer 只按
        // “VERTICAL_COLLISION && 上一 tick 的 Y 速度 < 0”判定着地。若只把 onGround
        // 折叠成 VERTICAL_COLLISION，站立/贴方块时 Y 速度为 0，会被误判为未着地，
        // Java 服务端随后回拉位置。这里在移动翻译前给当前 tick 一个极小的向下速度，
        // 让旧逻辑正确判为 onGround；包本身的位置不变。
        Boolean onGround = org.cloudburstmc.protocol.bedrock.codec.v766_netease.serializer.PlayerAuthInputSerializer_v766_NetEase.consumeOnGround();
        ensureStepSniffer();
        stepTrace.record(packet, onGround, session.isFlying(),
                session.getGameMode() == null ? "?" : session.getGameMode().name());
        // 冷却显示仍交给 Geyser 标准翻译器；BossBar 是并行的兜底可见提示。
        boolean missedSwing = packet.getInputData().contains(PlayerAuthInputData.MISSED_SWING);
        PacketSignal signal = defaultHandler(packet);
        if (missedSwing) {
            startBossBarCooldown();
        }
        return signal;
    }

    @Override
    public PacketSignal handle(LevelSoundEventPacket packet) {
        // 标准 BedrockLevelSoundEventTranslator 会在 ATTACK/ATTACK_STRONG 时
        // 调用 setCooldownHitTime；这里只额外启动纯服务端 BossBar。
        SoundEvent sound = packet.getSound();
        PacketSignal signal = defaultHandler(packet);
        if (sound == SoundEvent.ATTACK || sound == SoundEvent.ATTACK_STRONG) {
            startBossBarCooldown();
        }
        return signal;
    }

    /**
     * 记录网易客户端发来的聊天包，便于定位“聊天不可用”问题（仅 debug 模式打印）。
     * 不在 debug 模式下做任何额外处理，转发行为与之前完全一致。
     */
    @Override
    public PacketSignal handle(TextPacket packet) {
        NeteaseExtension.debug("[GeyserNetease] 收到 TextPacket type=" + packet.getType()
            + " message='" + packet.getMessage() + "' filtered='" + packet.getFilteredMessage()
            + "' sourceName='" + packet.getSourceName() + "' xuid='" + packet.getXuid() + "'");
        return defaultHandler(packet);
    }

    @Override
    public PacketSignal handle(ClientToServerHandshakePacket packet) {
        if (neteaseSession != null && neteaseSession.loginDeferred()) {
            neteaseSession.setLoginDeferred(false);
            if (this.resourcePackLoadEvent == null) {
                this.resourcePackLoadEvent = new org.geysermc.geyser.event.type.SessionLoadResourcePacksEventImpl(session);
                this.geyser.eventBus().fireEventElseKick(this.resourcePackLoadEvent, session);
            }
            if (session.isClosed()) return PacketSignal.HANDLED;
            session.integratedPackActive(resourcePackLoadEvent.isIntegratedPackActive());
            sendLoginSuccessAndPacks();
            return PacketSignal.HANDLED;
        }
        return super.handle(packet);
    }

    @Override
    public PacketSignal handle(ResourcePackClientResponsePacket packet) {
        if (neteaseSession == null) return super.handle(packet);
        if (session.getUpstream().isClosed() || session.isClosed()) return PacketSignal.HANDLED;
        if (finishedResourcePackSending) return PacketSignal.HANDLED;

        switch (packet.getStatus()) {
            case COMPLETED -> {
                finishedResourcePackSending = true;
                if (geyser.config().java().authType() != AuthType.ONLINE) {
                    String javaName = javaLoginName(session.getAuthData().name(), neteaseSession.uid());
                    NeteaseExtension.debug("[GeyserNetease] Java 侧登录名 = " + javaName
                        + "（Bedrock 显示名 = " + session.getAuthData().name() + "，ASCII=" + ASCII_JAVA_NAME + "）");
                    session.authenticate(javaName);
                } else if (!couldLoginUserByName(session.getAuthData().name())) {
                    session.connect();
                }
                neteaseSession.setAuthenticated(true);
                // authenticate() 会同步创建 downstream 会话对象，返回后立刻挂监听器，
                // 这样第一个包（握手/LoginStart）也能被记录到。
                attachJavaSniffer();
            }
            case SEND_PACKS -> { if (!packet.getPackIds().isEmpty()) { packsToSend.addAll(packet.getPackIds()); sendPackDataInfo(packsToSend.pop()); } return PacketSignal.HANDLED; }
            case HAVE_ALL_PACKS -> {
                ResourcePackStackPacket sp = new ResourcePackStackPacket();
                sp.setExperimentsPreviouslyToggled(false); sp.setForcedToAccept(false);
                sp.setGameVersion(session.getClientData() != null
                        ? session.getClientData().getGameVersion() : sessionGameVersion());
                sp.getResourcePacks().addAll(this.resourcePackLoadEvent.orderedPacks()); session.sendUpstreamPacket(sp);
            }
            case REFUSED -> session.disconnect("disconnectionScreen.resourcePack");
            default -> session.disconnect("disconnectionScreen.resourcePack");
        }
        return PacketSignal.HANDLED;
    }

    public PacketSignal handle(NetEaseJsonPacket p)  { return PacketSignal.HANDLED; }
    public PacketSignal handle(PyRpcPacket p)         { return PacketSignal.HANDLED; }
    public PacketSignal handle(StoreBuySuccessPacket p) { return PacketSignal.HANDLED; }
    public PacketSignal handle(ConfirmSkinPacket p)   { return PacketSignal.HANDLED; }

    public PacketSignal handle(InventoryTransactionPacket packet) {
        // 网易不同客户端版本对实体攻击的 transactionType 可能落在 ITEM_USE_ON_ENTITY
        // 或 NORMAL；actionType=1 才是攻击。放宽到这两种，避免冷却在发包前被静默漏掉。
        boolean attack = packet.getActionType() == 1
                && (packet.getTransactionType() == InventoryTransactionType.ITEM_USE_ON_ENTITY
                || packet.getTransactionType() == InventoryTransactionType.NORMAL);
        if (attack) {
            // 不丢包、不自行计时：BedrockInventoryTransactionTranslator 会转发攻击，
            // 并在标准冷却链路里记录 lastHitTime；伤害节奏由 Java 服务端按原版处理。
            NeteaseExtension.debug("[GeyserNetease] 攻击交回标准冷却: transaction="
                    + packet.getTransactionType() + " action=" + packet.getActionType()
                    + " attackSpeed=" + session.getAttackSpeed());
            PacketSignal signal = defaultHandler(packet);
            startBossBarCooldown();
            return signal;
        }
        if (neteaseSession != null && packet.getTransactionType() == InventoryTransactionType.NORMAL
                && packet.getActions().size() == 2) {
            List<InventoryActionData> actions = packet.getActions();
            InventoryActionData action0 = actions.get(0);
            InventoryActionData action1 = actions.get(1);
            // source / toItem 都由客户端数据构造，畸形包可能为 null，先判空再取字段。
            InventorySource source0 = action0.getSource();
            InventorySource source1 = action1.getSource();
            if (source0 == null || source1 == null) return defaultHandler(packet);
            InventoryActionData worldAction = source0.getType() == InventorySource.Type.WORLD_INTERACTION ? action0 : action1;
            InventoryActionData containerAction = (worldAction == action0) ? action1 : action0;
            if (worldAction.getSource().getType() != InventorySource.Type.WORLD_INTERACTION
                    || containerAction.getSource().getType() != InventorySource.Type.CONTAINER)
                return defaultHandler(packet);
            // 普通交互（使用物品、放置、拾取等）也会出现 WORLD_INTERACTION 来源，
            // 只有带 DROP_ITEM 标志的才是“丢弃”，否则会把正常操作误判成丢物品。
            if (worldAction.getSource().getFlag() != InventorySource.Flag.DROP_ITEM)
                return defaultHandler(packet);
            if (worldAction.getToItem() == null) return defaultHandler(packet);

            var inventory = session.getPlayerInventory();
            if (inventory == null || inventory.getHeldItemSlot() != containerAction.getSlot())
                // 从背包界面丢弃非快捷栏物品需要发容器点击包；这里交回 Geyser 的标准实现，
                // 避免误丢当前手持物品。
                return defaultHandler(packet);
            boolean dropAll = worldAction.getToItem().getCount() > 1;
            if (inventory.getItemInHand() == null || inventory.getItemInHand().isEmpty())
                return PacketSignal.HANDLED;

            session.sendDownstreamGamePacket(new ServerboundPlayerActionPacket(
                dropAll ? PlayerAction.DROP_ITEM_STACK : PlayerAction.DROP_ITEM, Vector3i.ZERO, Direction.DOWN, 0));

            if (dropAll) inventory.setItemInHand(org.geysermc.geyser.inventory.GeyserItemStack.EMPTY);
            else inventory.getItemInHand().sub(1);

            return PacketSignal.HANDLED;
        }
        return defaultHandler(packet);
    }

    /**
     * 网易会话的纯服务端 BossBar 冷却提示。
     * 标准 CooldownUtils 链路保持不变；BossBar 只作为额外可见 HUD。
     */
    private void startBossBarCooldown() {
        if (neteaseSession == null || session.isClosed()
                || !session.isSpawned() || session.getPlayerEntity() == null) {
            return;
        }
        if (NeteaseExtension.CONFIG == null || !NeteaseExtension.CONFIG.bossBarCooldown()) {
            return;
        }
        double seconds = bossBarCooldownSeconds();
        if (seconds <= 0.0) {
            return;
        }
        long now = System.currentTimeMillis();
        // 实体攻击、攻击音效和挥空可能在同一 tick 内先后到达；避免同一次点击
        // 把 BossBar 反复重置成满进度。
        if (lastBossBarStartMs != 0L && now - lastBossBarStartMs < 20L) {
            return;
        }
        lastBossBarStartMs = now;
        long windowMs = Math.max(1L, Math.round(seconds * 1000.0));
        if (bossBarEntityId == 0L) {
            bossBarEntityId = newBossBarEntityId();
        }
        long generation = ++bossBarGeneration;
        if (!bossBarVisible) {
            addBossBarEntity();
            sendBossBarCreate();
            bossBarVisible = true;
            NeteaseExtension.debug("[GeyserNetease] BossBar 冷却创建: " + seconds + "s");
        } else {
            updateBossBarProgress(1.0f);
            NeteaseExtension.debug("[GeyserNetease] BossBar 冷却重置: " + seconds + "s");
        }
        scheduleBossBarFrame(generation, now, windowMs);
    }

    private double bossBarCooldownSeconds() {
        double attackSpeed = session.getAttackSpeed();
        if (!(attackSpeed > 0.0) || attackSpeed > 20.0) {
            return 0.0;
        }
        double tickMillis = session.getMillisecondsPerTick();
        if (!(tickMillis > 0.0)) {
            tickMillis = 50.0;
        }
        double seconds = Math.max(tickMillis / 50.0, 1.0) / attackSpeed;
        return Double.isFinite(seconds) && seconds > 0.0 ? seconds : 0.0;
    }

    private long newBossBarEntityId() {
        long id = ThreadLocalRandom.current().nextLong() & Long.MAX_VALUE;
        return id == 0L ? 1L : id;
    }

    private void addBossBarEntity() {
        if (session.getPlayerEntity() == null) {
            return;
        }
        AddEntityPacket add = new AddEntityPacket();
        add.setUniqueEntityId(bossBarEntityId);
        add.setRuntimeEntityId(bossBarEntityId);
        add.setIdentifier("minecraft:creeper");
        add.setEntityType(33);
        add.setPosition(session.getPlayerEntity().position().down(10.0f));
        add.setRotation(Vector2f.ZERO);
        add.setMotion(Vector3f.ZERO);
        add.getMetadata().put(EntityDataTypes.SCALE, 0.0f);
        add.getMetadata().put(EntityDataTypes.WIDTH, 0.0f);
        add.getMetadata().put(EntityDataTypes.HEIGHT, 0.0f);
        session.sendUpstreamPacket(add);
    }

    private void sendBossBarCreate() {
        BossEventPacket packet = new BossEventPacket();
        packet.setBossUniqueEntityId(bossBarEntityId);
        packet.setAction(BossEventPacket.Action.CREATE);
        packet.setTitle("攻击冷却");
        packet.setFilteredTitle("攻击冷却");
        packet.setHealthPercentage(1.0f);
        packet.setColor(4); // yellow
        packet.setOverlay(0); // progress bar
        packet.setDarkenSky(0);
        session.sendUpstreamPacket(packet);
    }

    private void updateBossBarProgress(float progress) {
        BossEventPacket packet = new BossEventPacket();
        packet.setBossUniqueEntityId(bossBarEntityId);
        packet.setAction(BossEventPacket.Action.UPDATE_PERCENTAGE);
        packet.setHealthPercentage(Math.max(0.0f, Math.min(1.0f, progress)));
        session.sendUpstreamPacket(packet);
    }

    private void scheduleBossBarFrame(long generation, long started, long windowMs) {
        if (session.isClosed() || generation != bossBarGeneration) {
            return;
        }
        session.scheduleInEventLoop(() -> {
            if (session.isClosed() || generation != bossBarGeneration) {
                return;
            }
            long elapsed = System.currentTimeMillis() - started;
            if (elapsed >= windowMs) {
                updateBossBarProgress(0.0f);
                removeBossBar();
                return;
            }
            updateBossBarProgress(1.0f - (float) elapsed / (float) windowMs);
            scheduleBossBarFrame(generation, started, windowMs);
        }, 50L, TimeUnit.MILLISECONDS);
    }

    private void removeBossBar() {
        if (!bossBarVisible) {
            return;
        }
        BossEventPacket packet = new BossEventPacket();
        packet.setBossUniqueEntityId(bossBarEntityId);
        packet.setAction(BossEventPacket.Action.REMOVE);
        session.sendUpstreamPacket(packet);

        RemoveEntityPacket remove = new RemoveEntityPacket();
        remove.setUniqueEntityId(bossBarEntityId);
        session.sendUpstreamPacket(remove);
        bossBarVisible = false;
        NeteaseExtension.debug("[GeyserNetease] BossBar 冷却结束并移除");
    }

    private static void startEncryptionHandshake(GeyserSession session, PublicKey clientKey) throws Exception {
        KeyPair serverKeyPair = EncryptionUtils.createKeyPair();
        byte[] token = EncryptionUtils.generateRandomToken();

        ServerToClientHandshakePacket handshake = new ServerToClientHandshakePacket();
        handshake.setJwt(EncryptionUtils.createHandshakeJwt(serverKeyPair, token));
        session.sendUpstreamPacketImmediately(handshake);

        SecretKey encryptionKey = EncryptionUtils.getSecretKey(serverKeyPair.getPrivate(), clientKey, token);
        session.getUpstream().getSession().enableEncryption(encryptionKey);
    }

    private Integer getRakVersion() {
        try { return session.getUpstream().getSession().getPeer().getChannel().config().getOption(RakChannelOption.RAK_PROTOCOL_VERSION); }
        catch (Exception e) { return null; }
    }
    private boolean couldLoginUserByName(String name) {
        if (geyser.config().savedUserLogins().contains(name)) {
            String chain = geyser.authChainFor(name);
            if (chain != null) { session.authenticateWithAuthChain(chain); return true; }
        }
        return false;
    }

    public NeteaseSession neteaseSession() { return neteaseSession; }

    /**
     * Java 侧登录名。
     *
     * <p>网易客户端的显示名是中文（如 "锕钼铽镧锶"）。Geyser 会原样把它交给 MCProtocolLib
     * 作为 java 版 LoginStart 的用户名，而实测该用户名会让 Velocity 侧在登录阶段静默掐断连接
     * （Velocity 的 MinecraftConnection.exceptionCaught 对 InitialLoginSessionHandler /
     * HandshakeSessionHandler 这类"前线"处理器不打任何日志，直接 ctx.close()）。
     * 因此默认改用纯 ASCII、稳定的 java 登录名；Bedrock 侧显示名不变。</p>
     *
     * <p>可用 {@code -DGeyserNetease.AsciiJavaName=false} 关闭，恢复原来的中文名登录。</p>
     */
    private static final boolean ASCII_JAVA_NAME =
        "true".equalsIgnoreCase(System.getProperty("GeyserNetease.AsciiJavaName", "true"));

    private static String javaLoginName(String bedrockName, long uid) {
        if (!ASCII_JAVA_NAME) return bedrockName;
        String base = "NE" + Math.abs(uid);
        if (base.length() > 16) base = base.substring(0, 16);
        return base;
    }

    /**
     * Java 侧地址（用于 Geyser 的 {@code session.joinAddress()}，也就是 java 握手的 hostname）。
     *
     * <p>网易局域网客户端的客户端数据里 {@code ServerAddress} 是 {@code ":0"}，
     * 于是 {@code GeyserSession.joinAddress()} = {@code substring(0, 0)} = 空字符串，
     * 若 Geyser 配置了 {@code forward-hostname: true}，java 握手就会带着空 hostname 发给代理；
     * Velocity 收到空 hostname 会在登录阶段直接静默掐断连接（
     * {@code MinecraftConnection.exceptionCaught} 对 InitialLoginSessionHandler 不打日志）。
     * 这里强制填一个真实的公开地址。可用 {@code -DGeyserNetease.ServerAddress=...} 覆盖。</p>
     */
    private static final String SERVER_ADDRESS_PROPERTY = System.getProperty("GeyserNetease.ServerAddress");
    private static volatile String resolvedServerAddress;
    private static volatile boolean serverAddressResolved;

    private static String serverAddress(GeyserImpl geyser) {
        if (serverAddressResolved) return resolvedServerAddress;
        synchronized (NetEaseUpstreamHandler.class) {
            if (serverAddressResolved) return resolvedServerAddress;
            resolvedServerAddress = resolveServerAddress(geyser);
            serverAddressResolved = true;
            return resolvedServerAddress;
        }
    }

    private static String resolveServerAddress(GeyserImpl geyser) {
        String property = SERVER_ADDRESS_PROPERTY;
        if (property != null && !property.isBlank()) {
            NeteaseExtension.debug("[GeyserNetease] ServerAddress 取启动参数: " + property.trim());
            return property.trim();
        }
        try {
            String host = geyser.config().bedrock().address();
            int port = geyser.config().bedrock().port();
            if (host != null && !host.isBlank() && !isWildcard(host)) {
                String value = host + ":" + port;
                NeteaseExtension.debug("[GeyserNetease] ServerAddress 取 Geyser 监听地址: " + value);
                return value;
            }
            String local = java.net.InetAddress.getLocalHost().getHostName();
            if (local != null && !local.isBlank()) {
                String value = local + ":" + port;
                NeteaseExtension.debug("[GeyserNetease] ServerAddress 取本机主机名: " + value);
                return value;
            }
        } catch (Throwable t) {
            NeteaseExtension.LOG.warning("[GeyserNetease] 推断 ServerAddress 失败: " + t);
        }
        NeteaseExtension.LOG.warning("[GeyserNetease] 无法推断 ServerAddress，请设置 "
                + "-DGeyserNetease.ServerAddress=域名:端口；本次保持客户端原值（forward-hostname 下可能被代理静默断流）");
        return null;
    }

    private static boolean isWildcard(String host) {
        return "0.0.0.0".equals(host) || "::".equals(host) || "[::]".equals(host) || "*".equals(host);
    }

    /** 从解析出的地址里取主机部分（去掉端口）。 */
    private static String handshakeHost(GeyserImpl geyser) {
        String value = serverAddress(geyser);
        if (value == null) return null;
        int i = value.lastIndexOf(':');
        return i > 0 ? value.substring(0, i) : value;
    }

    /** 把客户端数据里的 ServerAddress 从 ":0" 修成一个正常地址；已经是正常值则不动。 */
    private static void patchServerAddress(BedrockClientData bcd, String address) {
        if (bcd == null || address == null || address.isBlank()) return;
        try {
            String cur = bcd.getServerAddress();
            if (cur != null && !cur.isEmpty() && !cur.startsWith(":")) return;
            boolean ok = false;
            try {
                var m = BedrockClientData.class.getDeclaredMethod("setServerAddress", String.class);
                m.setAccessible(true);
                m.invoke(bcd, address);
                ok = true;
            } catch (Throwable ignored) {
            }
            if (!ok) {
                var f = BedrockClientData.class.getDeclaredField("serverAddress");
                f.setAccessible(true);
                f.set(bcd, address);
            }
            NeteaseExtension.debug("[GeyserNetease] 客户端 ServerAddress \"" + cur + "\" → \""
                + address + "\"（java 握手 hostname 依赖它）");
        } catch (Throwable e) {
            NeteaseExtension.LOG.error("[GeyserNetease] 修正 ServerAddress 失败: " + e);
        }
    }

    // ==================== Java 侧嗅探（诊断用） ====================
    //
    // 目的：网易玩家在 "Geyser → Velocity" 这一跳会被静默断流（Velocity 的
    // MinecraftConnection.exceptionCaught 对 InitialLoginSessionHandler /
    // HandshakeSessionHandler 这类"前线"处理器不打任何日志，直接 ctx.close()；
    // 解码失败又是 QuietRuntimeException），因此服务器日志里什么都看不到。
    //
    // 这里在 Geyser 的 downstream（MCProtocolLib）会话上挂一个 SessionListener：
    //   packetSending  → Geyser 发往 Velocity 的每一个包（含握手/LoginStart）
    //   packetReceived → Velocity 发来的每一个包（含 LoginSuccess/Disconnect）
    //   packetError / disconnecting / disconnected → 异常与断开原因
    // 结果写入运行目录下的 geyser-netease-java.log。
    private static volatile java.io.PrintWriter SNIFF_OUT;
    private static volatile String SNIFF_PATH = "(未初始化)";
    private static final java.util.concurrent.atomic.AtomicBoolean SNIFF_STARTED =
        new java.util.concurrent.atomic.AtomicBoolean();
    private static final java.util.concurrent.atomic.AtomicInteger SNIFF_CONSOLE =
        new java.util.concurrent.atomic.AtomicInteger();

    private static final boolean SNIFF_ENABLED =
        Boolean.parseBoolean(System.getProperty("GeyserNetease.Sniff", "false"));

    /** 台阶诊断：监听 Java 位置校正包，并在 Java 会话断开时落盘 step-trace。 */
    private void ensureStepSniffer() {
        if (!NeteaseExtension.packetTrace() || stepSnifferAttached) return;
        var downstream = session.getDownstream();
        if (downstream == null || downstream.getSession() == null) return;
        downstream.getSession().addListener(new org.geysermc.mcprotocollib.network.event.session.SessionAdapter() {
            @Override
            public void packetReceived(org.geysermc.mcprotocollib.network.Session s,
                                       org.geysermc.mcprotocollib.network.packet.Packet p) {
                if (p.getClass().getSimpleName().contains("PlayerPosition")) {
                    stepTrace.markServerCorrection();
                }
            }

            @Override
            public void disconnected(
                    org.geysermc.mcprotocollib.network.event.session.DisconnectedEvent event) {
                stepTrace.flush();
            }
        });
        stepSnifferAttached = true;
    }

    private void attachJavaSniffer() {
        if (!SNIFF_ENABLED) return;
        if (!SNIFF_STARTED.compareAndSet(false, true)) return;
        try {
            java.io.File f = new java.io.File("geyser-netease-java.log");
            SNIFF_PATH = f.getAbsolutePath();
            SNIFF_OUT = new java.io.PrintWriter(new java.io.FileWriter(f, true), true);
            NeteaseExtension.debug("[GeyserNetease] Java 侧嗅探日志: " + SNIFF_PATH);
            sniff("===== 嗅探启动 bedrockName="
                + (session.getAuthData() != null ? session.getAuthData().name() : "?")
                + " xuid=" + session.xuid() + " path=" + SNIFF_PATH, null);

            var ds = session.getDownstream();
            if (ds == null || ds.getSession() == null) {
                sniff("!! downstream 尚未创建，无法挂监听器", null);
                return;
            }
            var javaSession = ds.getSession();
            sniff("downstream session = " + javaSession.getClass().getName(), null);
            try {
                var rs = session.remoteServer();
                sniff("诊断: forwardHostname=" + geyser.config().java().forwardHostname()
                    + " joinAddress=\"" + session.joinAddress() + "\""
                    + " remoteServer=" + (rs != null ? (rs.address() + ":" + rs.port() + " auth=" + rs.authType()) : "null")
                    + " clientData.ServerAddress=\"" + (session.getClientData() != null
                        ? session.getClientData().getServerAddress() : "null") + "\""
                    + " 强制地址=" + serverAddress(geyser), null);
            } catch (Throwable t) {
                sniff("诊断信息读取失败: " + t, null);
            }

            javaSession.addListener(new org.geysermc.mcprotocollib.network.event.session.SessionAdapter() {
                @Override
                public void packetSending(
                        org.geysermc.mcprotocollib.network.event.session.PacketSendingEvent event) {
                    var p = event.getPacket();
                    // 兜底：handshake 的 hostname 为空会导致 Velocity 静默断流
                    if (p instanceof org.geysermc.mcprotocollib.protocol.packet.handshake.serverbound.ClientIntentionPacket ip
                            && (ip.getHostname() == null || ip.getHostname().isEmpty())) {
                        String host = handshakeHost(geyser);
                        event.setPacket(ip.withHostname(host));
                        sniff("!! 握手 hostname 为空 → 改写为 \"" + host + "\"", null);
                        p = event.getPacket();
                    }
                    sniff("出→ " + p.getClass().getSimpleName() + " " + brief(p), null);
                }

                @Override
                public void packetReceived(org.geysermc.mcprotocollib.network.Session s,
                                           org.geysermc.mcprotocollib.network.packet.Packet p) {
                    sniff("入← " + p.getClass().getSimpleName() + " " + brief(p), null);
                }

                @Override
                public void packetError(
                        org.geysermc.mcprotocollib.network.event.session.PacketErrorEvent event) {
                    sniff("!! 包错误: " + event.getCause() + " packet=" + event.getPacketClass(), null);
                }

                @Override
                public void connected(org.geysermc.mcprotocollib.network.event.session.ConnectedEvent event) {
                    sniff("== Java 通道建立（即将发送握手）==", null);
                }

                @Override
                public void disconnecting(
                        org.geysermc.mcprotocollib.network.event.session.DisconnectingEvent event) {
                    sniff("== 正在断开: reason=" + event.getReason() + " cause=" + event.getCause(), null);
                }

                @Override
                public void disconnected(
                        org.geysermc.mcprotocollib.network.event.session.DisconnectedEvent event) {
                    sniff("== 已断开: reason=" + event.getReason() + " cause=" + event.getCause(), null);
                }
            });
            sniff("已注册 Java 会话监听器（监听器数=" + javaSession.getListeners().size() + "）", null);
        } catch (Throwable e) {
            sniff("!! 嗅探器挂载失败: " + e, null);
        }
    }

    /** 只记录关键包的细节，避免日志爆炸。 */
    private static String brief(Object p) {
        String n = p.getClass().getSimpleName();
        boolean key = n.contains("Hello") || n.contains("Intention") || n.contains("Acknowledged")
            || n.contains("Disconnect") || n.contains("Finished") || n.contains("Compression")
            || n.contains("LoginSuccess") || n.contains("CustomQuery");
        if (!key) return "";
        String s = String.valueOf(p);
        return s.length() > 400 ? s.substring(0, 400) + "..." : s;
    }

    private static void sniff(String tag, byte[] raw) {
        String line = "[" + java.time.LocalTime.now().withNano(0) + "] " + tag
            + (raw != null ? " len=" + raw.length + " " + hex(raw) : "");
        java.io.PrintWriter out = SNIFF_OUT;
        if (out != null) {
            out.println(line);
        } else {
            NeteaseExtension.LOG.info("[GeyserNetease][JavaSniff] " + line);
        }
        if (SNIFF_CONSOLE.incrementAndGet() <= 120) {
            NeteaseExtension.LOG.info("[GeyserNetease][JavaSniff] " + line);
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            sb.append(Character.forDigit((x >> 4) & 0xf, 16));
            sb.append(Character.forDigit(x & 0xf, 16));
        }
        return sb.toString();
    }

    private String sessionGameVersion() {
        try {
            var codec = session.getUpstream().getSession().getCodec();
            if (codec != null && codec.getMinecraftVersion() != null && !codec.getMinecraftVersion().isBlank()) {
                return codec.getMinecraftVersion();
            }
        } catch (Throwable ignored) {
        }
        return "1.21.130";
    }

    private static BedrockClientData buildFakeClientData(String name, String gameVersion) {
        String safeName = name == null ? "NetEasePlayer" : name.replace("\\", "\\\\").replace("\"", "\\\"");
        String safeVersion = gameVersion == null ? "1.21.130"
                : gameVersion.replace("\\", "\\\\").replace("\"", "\\\"");
        return GeyserImpl.GSON.fromJson(
            "{\"GameVersion\":\"" + safeVersion + "\",\"LanguageCode\":\"en_us\",\"DeviceOS\":1," +
            "\"DeviceModel\":\"NetEase\",\"ThirdPartyName\":\"" + safeName + "\"," +
            "\"SkinId\":\"\",\"SkinData\":\"\",\"SkinImageWidth\":64,\"SkinImageHeight\":64," +
            "\"CapeId\":\"\",\"CapeData\":\"\",\"CapeImageWidth\":64,\"CapeImageHeight\":32," +
            "\"SkinGeometryData\":\"\",\"SkinResourcePatch\":\"\"," +
            "\"SkinGeometryDataEngineVersion\":\"\",\"PlayFabId\":\"\"," +
            "\"PersonaSkin\":false,\"PremiumSkin\":false,\"IsEditorMode\":false," +
            "\"SkinColor\":\"#0\",\"ArmSize\":\"wide\",\"PersonaPieces\":[],\"PieceTintColors\":[]}",
            BedrockClientData.class);
    }

    private static UUID toStableUUID(String rawIdentity, long neteaseUid) {
        if (rawIdentity != null && !rawIdentity.isEmpty()) {
            String hex = rawIdentity.replace("-", "");
            if (hex.length() == 32) {
                try {
                    return UUID.fromString(
                        hex.substring(0, 8) + "-" + hex.substring(8, 12) + "-" + hex.substring(12, 16) + "-"
                        + hex.substring(16, 20) + "-" + hex.substring(20));
                } catch (IllegalArgumentException ignored) {}
            }
        }
        String seed = "netease:player:" + neteaseUid;
        return UUID.nameUUIDFromBytes(seed.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
}
