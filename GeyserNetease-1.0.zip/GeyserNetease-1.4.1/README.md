# GeyserNetease 扩展

让 **网易版 Minecraft（中国版基岩版）** 玩家连接到使用 Geyser 的服务器。

简单来说：如果你有一个 Java 版服务器并用 Geyser 让基岩版玩家进来玩，装上这个扩展之后，**网易版玩家也能进来**。

支持同时在线：

- ✅ Java 版玩家
- ✅ 国际版基岩版玩家
- ✅ **网易版基岩版玩家**（本扩展）

> 作者：EiluDick / ZDarkZ · 本仓库额外做了 **Geyser 2.12.1 / 协议 860 与网易 898（1.21.130）适配** 与 **Java 握手 hostname 修复**（见「已知问题」）

---

## 为什么需要它

网易版虽然也是基岩版，但与国际版有几处关键差异，默认 Geyser 接不了：

| 差异 | 扩展的处理 |
|---|---|
| RakNet 协议版本不同（网易 = **8**） | 重绑 Geyser 的 RakNet 监听（`ServerRestartUtil` + `NeteaseServerInitializer`），识别 `rakVer=8` 走网易链路 |
| 协议版本自定义（630 / 686 / 766 / 819 / 860 / 898 …） | 自带 `NeteaseCodecRegistry`，按客户端上报的协议版本选择 codec |
| **不做 Bedrock 层加密** | 网易局域网数据通道本身由 DTLS 加密，客户端收到 `ServerToClientHandshake` 会静默忽略，因此跳过握手直接进入资源包阶段 |
| 方块哈希与官方不同 | `SpoofedUpstream` 重写方块运行时 ID、StartGame 调色板、`ConfirmSkin` |
| 客户端数据里 `ServerAddress` 为 `":0"` | **修正为真实地址**，否则 Geyser 会带空 hostname 连代理并被静默掐断（见「已知问题 1」） |

---

## 前置要求

1. 已安装 **Geyser**（本扩展不能单独运行），扩展 API **2.9.10+**；本仓库构建目标为 **Geyser core 2.12.1-SNAPSHOT**（bedrock-codec 3.0.0.Beta15、RakNet CR6）
2. **Java 21**
3. 平台：Geyser 各平台均可（Standalone / Velocity / BungeeCord / Spigot / Fabric / NeoForge）

---

## 直接下载（免编译）

不想装 JDK / Gradle 的话，直接用仓库里随源码提交的预编译 jar：

**[`dist/GeyserNeteaseExtension.jar`](dist/GeyserNeteaseExtension.jar)**

| 项 | 值 |
|---|---|
| 文件大小 | 3,118,355 字节（3045 KB） |
| 构建时间 | 2026-10-07 00:49:55 |
| SHA256 | `3388f14b508d6c5e0dea5021ceb27647dded65b7b48a1531c78a3a51216dbdf9` |
| 适配 Geyser | 2.11.3 |
| 扩展版本 | 1.1.0 |
| 包含修复 | 下文「已知问题 1」的 java 握手 hostname 修复 |

`extension.yml` 元信息：

```yaml
id: geyser-netease
name: GeyserNetEase
main: nc.geyserext.netease.NeteaseExtension
version: 1.1.0
```

> 该 jar 与源码一一对应：构建后 `dist/` 与 `build/libs/` 的文件哈希一致，
> 想自己核对可以 `sha256sum dist/GeyserNeteaseExtension.jar`。

> ⚠️ **`ServerAddress` 不再回落到示例域名。**
> 未设置启动参数时，扩展依次取 Geyser 监听的 `address:port`、本机主机名；
> 代理或对外域名与监听地址不一致时，请用 `-DGeyserNetease.ServerAddress=你的域名:端口` 显式指定。

> 注意 `dist/` 里若还有 `GeyserNeteaseExtension-hostnamefix.jar` / `-sniff.jar`，
> 那是早期调试用的变体，**不要使用**，请始终用 `GeyserNeteaseExtension.jar`。

## 构建

```bash
# Windows
gradlew.bat shadowJar

# Linux / macOS
./gradlew shadowJar
```

产物：`build/libs/GeyserNeteaseExtension.jar`

构建完成后建议同步到 `dist/`，让仓库里的预编译包与源码保持一致：

```bash
cp build/libs/GeyserNeteaseExtension.jar dist/GeyserNeteaseExtension.jar
```

> 若 gradle wrapper 下载失败（企业网络 / 证书问题），可直接用本机 Gradle 构建：
> `gradle shadowJar --offline`

## 安装

1. 把 jar 放进 Geyser 的**扩展目录**（不是 `plugins/` 根目录）：

   | 平台 | 路径 |
   |---|---|
   | Standalone | `extensions/GeyserNeteaseExtension.jar` |
   | Velocity | `plugins/Geyser-Velocity/extensions/GeyserNeteaseExtension.jar` |
   | BungeeCord | `plugins/Geyser-BungeeCord/extensions/GeyserNeteaseExtension.jar` |
   | Spigot / Paper | `plugins/Geyser-Spigot/extensions/GeyserNeteaseExtension.jar` |

2. 文件名必须是 `GeyserNeteaseExtension.jar`（与 `extension.yml` 的 id 对应）
3. 重启服务器，日志出现下面两行即加载成功：

   ```
   [geyser-netease] NetEase Extension starting... [build geyser2.12.1-...]
   [geyser-netease] NetEase Extension initialized — RakNet v8 clients supported.
   ```

## 配置

首次启动会在扩展目录生成 `config.yml`：

```yaml
# true = 只允许网易客户端（RakNet 协议版本 8），国际版基岩版会被拒绝
only-netease-clients: false

# only-netease-clients: true 时给国际版玩家显示的踢出消息
disconnect-message: "This server only accepts NetEase clients."

# 详细日志（网易认证与包处理），排查连接问题时打开
debug-mode: false
```

### 可选 JVM 参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `-DGeyserNetease.ServerAddress` | 自动推断 | 修正网易客户端 `ServerAddress`（`:0`）用的地址。未设置时依次取 Geyser 监听的 `address:port`、本机主机名；代理（Velocity + `forward-hostname`）环境建议显式填 `域名:端口` |
| `-DGeyserNetease.SkipEncryption` | `true` | 跳过 Bedrock 层加密握手（网易局域网流程本就不加密）；设 `false` 可强制走 `ServerToClientHandshake` |
| `-DGeyserNetease.AsciiJavaName` | `true` | java 侧使用纯 ASCII 登录名（`NE+uid`），Bedrock 侧显示名不变；设 `false` 直接使用网易中文名（经 Velocity 有静默断流风险） |
| `-DGeyserNetease.Sniff` | `false` | `true` 时把 Geyser ↔ 代理 的双向包写入运行目录的 `geyser-netease-java.log`（排错用） |
| `-DGeyserNetease.Debug` | `false` | `true` 时输出逐连接的诊断日志（网易路径已激活 / 跳过加密握手 / `ServerAddress` 修正 / java 登录名等）。默认静默，只在排查时打开 |

### 支持的网易协议版本

当前只放行网易协议 **819 / 860 / 898**。客户端上报其它协议版本时，扩展会在登录前断开，并显示：

```text
您的网易Minecraft版本不受支持
```

### 网易 898 兼容开关（`config.yml`）

| 配置项 | 默认 | 说明 |
|---|---|---|
| `wire-format-898` | `v898` | `v860` 时把 StartGame/Text/命令包/Animate/MobEffect/Interact/Event/ResourcePackStack 回退到 860 时代线格式 |
| `animate-format-898-v4` | `netease` | Animate 包格式；网易 898 在 v898 后再写 VarLong 攻击 ID，旧 v1/v2/v3 键已废弃 |
| `attack-cooldown` | `true` | 兼容旧配置字段，当前不再控制冷却。冷却改由 Geyser 的 `show-cooldown` / `cooldown-type` 设置决定，与普通基岩版玩家一致 |
| `bossbar-cooldown` | `true` | 网易会话专用 BossBar 冷却条，标题“攻击冷却”、进度从满到空；不依赖客户端模组，也不影响标准冷却链路 |
| `packet-trace-v3` | `false` | 台阶/碰撞诊断；默认关闭，排障时临时打开；旧键 `packet-trace`、`packet-trace-v2` 已废弃并被忽略 |
| `auth-input-bitmap` | `netease` | `standard` 用原版 898 位图；`legacy` 复现旧的读写不对称实现（排障用） |
| `private-packet-ids` | 200/202/203/228 | 网易私有包 ID 覆盖；冲突或越界会自动回退默认值 |
| `confirm-skin-enabled` | `true` | 关闭后不下发 ConfirmSkin（皮肤确认失效，用于排除该包异常） |
| `log-dropped-packets` | `true` | 每类“当前 codec 不认识”的包告警一次，并给出原因 |

> 这些开关只在启动时读取，改动后需要重启 Geyser。

**为什么要修正 `ServerAddress`**：网易局域网客户端上报的 `ServerAddress` 是 `":0"`，
Geyser 的 `GeyserSession.joinAddress()` 取「最后一个 `:` 之前」的部分会得到**空字符串**。
配合 `forward-hostname: true`，java 握手就会带着空 hostname 发给代理，
代理在登录阶段**静默关闭连接**（不打任何日志），客户端只显示「数据流终止」。

未设置启动参数时，扩展会依次尝试 Geyser 配置的监听地址与本机主机名，避免再回落到示例域名；
代理或对外域名与监听地址不一致时，建议显式指定：

```bash
java -DGeyserNetease.ServerAddress=你的域名:19132 -jar geyser.jar
```

```ini
# 用 systemd / 启动脚本时，注意 -D 要放在 -jar 之前
ExecStart=/usr/bin/java -DGeyserNetease.ServerAddress=你的域名:19132 -jar /opt/geyser/geyser.jar
```

---

## 已知问题 / 排错

### 1. 客户端显示「数据流终止」；Geyser 日志只有「已因 §r数据流终止 与 Java 服务器断开了连接」；**代理（Velocity）一行日志都没有**

**原因**：网易客户端上报的客户端数据里 `"ServerAddress":":0"`，而 Geyser 的 `joinAddress()` 是把它按最后一个 `:` 截断：

```java
String combined = clientData.getServerAddress();   // ":0"
int index = combined.lastIndexOf(":");
return combined.substring(0, index);               // → ""
```

当 Geyser 配置了 `forward-hostname: true` 时，java 握手就会带上**空 hostname**。Velocity 在登录阶段遇到这种情况会**静默关闭连接**：
`MinecraftConnection.exceptionCaught` 对 `InitialLoginSessionHandler` / `HandshakeSessionHandler` 这类 frontline handler 不打任何日志，直接 `ctx.close()`；
而解码失败抛出的是 `QuietRuntimeException`。日志里的 `数据流终止` 其实是 Geyser 的 Java 协议库在通道关闭时合成的原版提示
（`Component.translatable("disconnect.endOfStream")`），**不是代理发的**。

**修复**：本版本在设置客户端数据时把 `ServerAddress` 修正为真实地址，并额外做了一次握手 hostname 兜底改写。修复后的嗅探日志：

```
出→ ClientIntentionPacket(protocolVersion=776, hostname=play.your-server.com, port=25565, intent=LOGIN)
出→ ServerboundHelloPacket(username=..., profileId=...)
入← ClientboundLoginFinishedPacket(profile=GameProfile{...})
入← ClientboundLoginPacket
入← ClientboundLevelChunkWithLightPacket × 377      ← 世界数据正常下发
```

记得把 `-DGeyserNetease.ServerAddress` 设成你自己的域名与端口。

### 2. 网易客户端连上了，但一个字节都不发，最后超时

这是**房主网关**侧的问题（NetherNet 数据通道丢首包），与本扩展无关，详见
[NeteaseBedrockGateway/docs/troubleshooting.md](../NeteaseBedrockGateway/docs/troubleshooting.md)。

### 3. 国际版玩家进不来

检查 `only-netease-clients` 是否为 `true`。

### 4. 扩展没有加载

- 确认 jar 放在**扩展目录**而不是 `plugins/` 根目录（放错会报 `Did not find a valid velocity-plugin.json`）
- 确认文件名是 `GeyserNeteaseExtension.jar`
- 确认 Geyser 版本满足扩展 API 要求（2.9.10+；本版本针对 2.12.1 构建）

---

## 仓库结构

```
GeyserNetease/
├── src/main/java/nc/geyserext/netease/
│   ├── NeteaseExtension.java                       扩展入口
│   ├── initializer/NeteaseServerInitializer.java   网易链路 pipeline（codec v3 + 不压缩）
│   ├── util/ServerRestartUtil.java                 重绑 Geyser 的 RakNet 监听
│   ├── util/protocol/NeteaseCodecRegistry.java     网易各协议版本 codec
│   ├── handler/NetEaseUpstreamHandler.java         网易登录流程（跳过加密 / 修 ServerAddress / 嗅探）
│   ├── session/SpoofedUpstream.java                方块哈希与 StartGame 伪装
│   └── config/                                     扩展配置
├── src/main/resources/{extension.yml,config.yml}
├── dist/
│   └── GeyserNeteaseExtension.jar                  ★ 随源码提交的构建产物，可直接安装
│                                                     SHA256 `3388f14b508d6c5e0dea5021ceb27647dded65b7b48a1531c78a3a51216dbdf9`
├── index.html / CNAME                              项目主页（GitHub Pages）
├── .gitignore / .gitattributes                     构建产物与换行符规则
└── build.gradle.kts / settings.gradle.kts / gradlew*
```

> 诊断版（逐包嗅探）不随仓库提交：自行 `gradlew shadowJar` 构建后，启动时加 `-DGeyserNetease.Sniff=true` 即可，日志写到运行目录的 `geyser-netease-java.log`。

## 常见问题

**Q：装了这个会影响国际版玩家吗？**
A：不会。默认配置下国际版与网易版都能正常游玩，互不影响。

**Q：网易玩家进来后能玩所有内容吗？**
A：大部分内容正常。网易版特有内容（部分皮肤、商城物品等）可能无法完全兼容。

**Q：这个扩展是官方的吗？**
A：不是，这是社区开发者制作的第三方扩展。

**Q：为什么要修正 `ServerAddress`？**
A：见「已知问题 1」——客户端上报的是 `":0"`，不修就会在 `Geyser → 代理` 这一跳被静默掐断。扩展现在会自动推断地址，代理环境仍建议用 `-DGeyserNetease.ServerAddress` 显式指定。

---

## 配套项目

- [NeteaseBedrockGateway](../NeteaseBedrockGateway)：网易「本地联机」程序房主网关（4399 登录 → 开房 → 把玩家流量转到本扩展所在的 Geyser）
- [GeyserMC/Geyser](https://github.com/GeyserMC/Geyser)

## 许可

MIT（见 [LICENSE](LICENSE)）。作者：EiluDick / ZDarkZ。
